package ru.ligrik.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class StoreApiClient {
    interface Callback<T> {
        void onSuccess(T value);
        void onError(String message);
    }

    private static final String BASE = "https://ligrik.ru/wp-json/wc/store/v1";
    private static final String PREFS = "ligrik_store_api";
    private static final String KEY_CART_TOKEN = "cart_token";

    private final Activity activity;
    private final SharedPreferences prefs;
    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile String cartToken;

    StoreApiClient(Activity activity) {
        this.activity = activity;
        this.prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.cartToken = prefs.getString(KEY_CART_TOKEN, "");
    }

    void getProducts(String search, String category, int perPage, Callback<List<StoreModels.Product>> cb) {
        Uri.Builder builder = Uri.parse(BASE + "/products").buildUpon();
        builder.appendQueryParameter("per_page", String.valueOf(Math.max(1, Math.min(100, perPage))));
        builder.appendQueryParameter("orderby", "menu_order");
        builder.appendQueryParameter("order", "asc");
        builder.appendQueryParameter("catalog_visibility", "visible");
        if (search != null && !search.trim().isEmpty()) builder.appendQueryParameter("search", search.trim());
        if (category != null && !category.trim().isEmpty()) builder.appendQueryParameter("category", category.trim());
        request("GET", builder.build().toString(), null, false, new Callback<Response>() {
            @Override public void onSuccess(Response r) {
                try {
                    JSONArray array = new JSONArray(r.body);
                    List<StoreModels.Product> products = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject o = array.optJSONObject(i);
                        if (o != null) products.add(StoreModels.Product.fromJson(o));
                    }
                    cb.onSuccess(products);
                } catch (Exception e) { cb.onError("Не удалось прочитать каталог магазина."); }
            }
            @Override public void onError(String message) { cb.onError(message); }
        });
    }

    void getProductsByIds(List<Integer> ids, Callback<List<StoreModels.Product>> cb) {
        if (ids == null || ids.isEmpty()) { cb.onSuccess(new ArrayList<>()); return; }
        StringBuilder include = new StringBuilder();
        for (int id : ids) {
            if (include.length() > 0) include.append(',');
            include.append(id);
        }
        Uri.Builder builder = Uri.parse(BASE + "/products").buildUpon();
        builder.appendQueryParameter("per_page", String.valueOf(Math.min(100, ids.size())));
        builder.appendQueryParameter("include", include.toString());
        builder.appendQueryParameter("orderby", "include");
        request("GET", builder.build().toString(), null, false, new Callback<Response>() {
            @Override public void onSuccess(Response r) {
                try {
                    JSONArray array = new JSONArray(r.body);
                    List<StoreModels.Product> products = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject o = array.optJSONObject(i);
                        if (o != null) products.add(StoreModels.Product.fromJson(o));
                    }
                    cb.onSuccess(products);
                } catch (Exception e) { cb.onError("Не удалось загрузить избранное."); }
            }
            @Override public void onError(String message) { cb.onError(message); }
        });
    }

    void getProduct(int id, Callback<StoreModels.Product> cb) {
        request("GET", BASE + "/products/" + id, null, false, new Callback<Response>() {
            @Override public void onSuccess(Response r) {
                try { cb.onSuccess(StoreModels.Product.fromJson(new JSONObject(r.body))); }
                catch (Exception e) { cb.onError("Не удалось открыть товар."); }
            }
            @Override public void onError(String message) { cb.onError(message); }
        });
    }

    void getCategories(Callback<List<StoreModels.Category>> cb) {
        Uri.Builder builder = Uri.parse(BASE + "/products/categories").buildUpon();
        builder.appendQueryParameter("per_page", "100");
        builder.appendQueryParameter("hide_empty", "true");
        request("GET", builder.build().toString(), null, false, new Callback<Response>() {
            @Override public void onSuccess(Response r) {
                try {
                    JSONArray array = new JSONArray(r.body);
                    List<StoreModels.Category> categories = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject o = array.optJSONObject(i);
                        if (o != null) categories.add(StoreModels.Category.fromJson(o));
                    }
                    cb.onSuccess(categories);
                } catch (Exception e) { cb.onError("Не удалось загрузить категории."); }
            }
            @Override public void onError(String message) { cb.onError(message); }
        });
    }

    void getCart(Callback<StoreModels.Cart> cb) {
        request("GET", BASE + "/cart", null, false, new Callback<Response>() {
            @Override public void onSuccess(Response r) { parseCart(r, cb); }
            @Override public void onError(String message) { cb.onError(message); }
        });
    }

    void addItem(int productId, int quantity, String childName, Callback<StoreModels.Cart> cb) {
        ensureCartToken(() -> {
            String cleanName = childName == null ? "" : childName.trim();
            Uri.Builder builder = Uri.parse(BASE + "/cart/add-item").buildUpon();
            builder.appendQueryParameter("id", String.valueOf(productId));
            builder.appendQueryParameter("quantity", String.valueOf(quantity));
            builder.appendQueryParameter("ligrik_native_app", "1");
            if (!cleanName.isEmpty()) builder.appendQueryParameter("ligrik_child_name", cleanName);

            JSONObject body = new JSONObject();
            try {
                body.put("id", productId);
                body.put("quantity", quantity);
                body.put("ligrik_native_app", "1");
                if (!cleanName.isEmpty()) body.put("ligrik_child_name", cleanName);
            } catch (Exception ignored) {}

            request("POST", builder.build().toString(), body, true, new Callback<Response>() {
                @Override public void onSuccess(Response r) { parseCart(r, cb); }
                @Override public void onError(String message) { cb.onError(message); }
            });
        }, cb::onError);
    }

    void updateItem(String key, int quantity, Callback<StoreModels.Cart> cb) {
        ensureCartToken(() -> {
            Uri.Builder builder = Uri.parse(BASE + "/cart/update-item").buildUpon();
            builder.appendQueryParameter("key", key);
            builder.appendQueryParameter("quantity", String.valueOf(quantity));
            request("POST", builder.build().toString(), new JSONObject(), true, new Callback<Response>() {
                @Override public void onSuccess(Response r) { parseCart(r, cb); }
                @Override public void onError(String message) { cb.onError(message); }
            });
        }, cb::onError);
    }

    void removeItem(String key, Callback<StoreModels.Cart> cb) {
        ensureCartToken(() -> {
            Uri.Builder builder = Uri.parse(BASE + "/cart/remove-item").buildUpon();
            builder.appendQueryParameter("key", key);
            request("POST", builder.build().toString(), new JSONObject(), true, new Callback<Response>() {
                @Override public void onSuccess(Response r) { parseCart(r, cb); }
                @Override public void onError(String message) { cb.onError(message); }
            });
        }, cb::onError);
    }

    void applyCoupon(String code, Callback<StoreModels.Cart> cb) {
        ensureCartToken(() -> {
            Uri.Builder builder = Uri.parse(BASE + "/cart/apply-coupon").buildUpon();
            builder.appendQueryParameter("code", code == null ? "" : code.trim());
            request("POST", builder.build().toString(), new JSONObject(), true, new Callback<Response>() {
                @Override public void onSuccess(Response r) { parseCart(r, cb); }
                @Override public void onError(String message) { cb.onError(message); }
            });
        }, cb::onError);
    }

    void updateCustomer(JSONObject billing, JSONObject shipping, Callback<StoreModels.Cart> cb) {
        ensureCartToken(() -> {
            JSONObject body = new JSONObject();
            try {
                body.put("billing_address", billing);
                body.put("shipping_address", shipping);
            } catch (Exception ignored) {}
            request("POST", BASE + "/cart/update-customer", body, true, new Callback<Response>() {
                @Override public void onSuccess(Response r) { parseCart(r, cb); }
                @Override public void onError(String message) { cb.onError(message); }
            });
        }, cb::onError);
    }

    void selectShippingRate(int packageId, String rateId, Callback<StoreModels.Cart> cb) {
        ensureCartToken(() -> {
            Uri.Builder builder = Uri.parse(BASE + "/cart/select-shipping-rate").buildUpon();
            builder.appendQueryParameter("package_id", String.valueOf(packageId));
            builder.appendQueryParameter("rate_id", rateId);
            request("POST", builder.build().toString(), new JSONObject(), true, new Callback<Response>() {
                @Override public void onSuccess(Response r) { parseCart(r, cb); }
                @Override public void onError(String message) { cb.onError(message); }
            });
        }, cb::onError);
    }

    void checkout(JSONObject billing, JSONObject shipping, String paymentMethod, String customerNote,
                  String expectedTotal, Callback<StoreModels.CheckoutResult> cb) {
        ensureCartToken(() -> {
            JSONObject body = new JSONObject();
            try {
                body.put("billing_address", billing);
                body.put("shipping_address", shipping);
                body.put("customer_note", customerNote == null ? "" : customerNote);
                body.put("create_account", false);
                body.put("payment_method", paymentMethod == null ? "" : paymentMethod);
                body.put("payment_data", new JSONArray());
                if (expectedTotal != null && !expectedTotal.isEmpty()) body.put("expected_total", expectedTotal);
            } catch (Exception ignored) {}
            request("POST", BASE + "/checkout", body, true, new Callback<Response>() {
                @Override public void onSuccess(Response r) {
                    try { cb.onSuccess(StoreModels.CheckoutResult.fromJson(new JSONObject(r.body))); }
                    catch (Exception e) { cb.onError("Заказ отправлен, но приложение не смогло прочитать ответ магазина."); }
                }
                @Override public void onError(String message) { cb.onError(message); }
            });
        }, cb::onError);
    }

    private void parseCart(Response r, Callback<StoreModels.Cart> cb) {
        try { cb.onSuccess(StoreModels.Cart.fromJson(new JSONObject(r.body))); }
        catch (Exception e) { cb.onError("Не удалось прочитать корзину магазина."); }
    }

    private interface Ready { void run(); }
    private interface Fail { void run(String message); }

    private void ensureCartToken(Ready ready, Fail fail) {
        if (cartToken != null && !cartToken.isEmpty()) { ready.run(); return; }
        request("GET", BASE + "/cart", null, false, new Callback<Response>() {
            @Override public void onSuccess(Response value) {
                if (cartToken == null || cartToken.isEmpty()) fail.run("Магазин не выдал токен корзины. Попробуйте ещё раз.");
                else ready.run();
            }
            @Override public void onError(String message) { fail.run(message); }
        });
    }

    private void request(String method, String url, JSONObject body, boolean requireCartToken, Callback<Response> cb) {
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(url).openConnection();
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(20000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestMethod(method);
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("User-Agent", "LIGRIK-Native-Android/5.4");
                connection.setRequestProperty("Origin", "https://ligrik.ru");
                connection.setRequestProperty("Referer", "https://ligrik.ru/");
                if (requireCartToken && cartToken != null && !cartToken.isEmpty()) {
                    connection.setRequestProperty("Cart-Token", cartToken);
                } else if (cartToken != null && !cartToken.isEmpty() && url.contains("/cart")) {
                    connection.setRequestProperty("Cart-Token", cartToken);
                }
                if (body != null && !"GET".equals(method)) {
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                    try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
                }
                int code = connection.getResponseCode();
                String newToken = connection.getHeaderField("Cart-Token");
                if (newToken != null && !newToken.isEmpty()) {
                    cartToken = newToken;
                    prefs.edit().putString(KEY_CART_TOKEN, newToken).apply();
                }
                InputStream stream = code >= 200 && code < 400 ? connection.getInputStream() : connection.getErrorStream();
                String responseBody = read(stream);
                if (code >= 200 && code < 300) {
                    deliverSuccess(cb, new Response(code, responseBody));
                } else {
                    String message = parseError(responseBody, code);
                    if ((code == 401 || code == 403) && requireCartToken) {
                        cartToken = "";
                        prefs.edit().remove(KEY_CART_TOKEN).apply();
                    }
                    deliverError(cb, message);
                }
            } catch (Exception e) {
                deliverError(cb, "Не удалось связаться с ligrik.ru. Проверьте интернет и повторите.");
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private String parseError(String body, int code) {
        try {
            JSONObject o = new JSONObject(body == null ? "{}" : body);
            String message = StoreModels.plain(o.optString("message", ""));
            if (!message.isEmpty()) return message;
        } catch (Exception ignored) {}
        return "Ошибка магазина (" + code + "). Попробуйте ещё раз.";
    }

    private String read(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private <T> void deliverSuccess(Callback<T> cb, T value) {
        main.post(() -> {
            if (!activity.isFinishing()) cb.onSuccess(value);
        });
    }

    private <T> void deliverError(Callback<T> cb, String message) {
        main.post(() -> {
            if (!activity.isFinishing()) cb.onError(message);
        });
    }

    private static final class Response {
        final int code;
        final String body;
        Response(int code, String body) { this.code = code; this.body = body == null ? "" : body; }
    }
}
