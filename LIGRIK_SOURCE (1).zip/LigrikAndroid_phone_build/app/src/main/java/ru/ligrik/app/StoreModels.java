package ru.ligrik.app;

import android.text.Html;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class StoreModels {
    private StoreModels() {}

    static String plain(String html) {
        if (html == null || html.isEmpty()) return "";
        String value;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            value = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString();
        } else {
            //noinspection deprecation
            value = Html.fromHtml(html).toString();
        }
        return value.replace('\u00a0', ' ').replaceAll("[ \\t]+", " ").replaceAll("\\n{3,}", "\\n\\n").trim();
    }

    static String formatMinor(String raw, int minor, String symbol) {
        try {
            long amount = Long.parseLong(raw == null || raw.isEmpty() ? "0" : raw);
            double value = amount / Math.pow(10, Math.max(0, minor));
            NumberFormat nf = NumberFormat.getNumberInstance(new Locale("ru", "RU"));
            nf.setMaximumFractionDigits(minor);
            nf.setMinimumFractionDigits(0);
            String s = nf.format(value);
            return s + " " + (symbol == null || symbol.isEmpty() ? "₽" : symbol);
        } catch (Exception e) {
            return (raw == null ? "" : raw) + " " + (symbol == null ? "" : symbol);
        }
    }

    static final class Product {
        int id;
        String name = "";
        String slug = "";
        String sku = "";
        String permalink = "";
        String summary = "";
        String shortDescription = "";
        String description = "";
        String priceRaw = "0";
        String regularPriceRaw = "0";
        String salePriceRaw = "0";
        String currency = "RUB";
        String currencySymbol = "₽";
        int minorUnit = 2;
        String productType = "standard";
        boolean customAmountEnabled;
        String customMinRaw = "0";
        String customMaxRaw = "0";
        String customSuggestedRaw = "0";
        boolean onSale;
        boolean purchasable = true;
        boolean inStock = true;
        final List<String> images = new ArrayList<>();
        final List<Category> categories = new ArrayList<>();
        final List<Attribute> attributes = new ArrayList<>();

        String priceText() { return isGiftCertificate() ? "Сумму выбирает покупатель" : formatMinor(priceRaw, minorUnit, currencySymbol); }
        String regularPriceText() { return formatMinor(regularPriceRaw, minorUnit, currencySymbol); }
        boolean isGiftCertificate() { return customAmountEnabled || "gift_certificate".equals(productType); }
        long customMin() { try { return Long.parseLong(customMinRaw); } catch (Exception e) { return 100L; } }
        long customMax() { try { return Long.parseLong(customMaxRaw); } catch (Exception e) { return 100000000L; } }
        long customSuggested() { try { return Long.parseLong(customSuggestedRaw); } catch (Exception e) { return 500000L; } }
        String primaryImage() { return images.isEmpty() ? "" : images.get(0); }
        String bodyText() {
            String text = plain(description);
            if (text.isEmpty()) text = plain(shortDescription);
            if (text.isEmpty()) text = plain(summary);
            return text;
        }
        boolean supportsPersonalRoof() {
            String n = name.toLowerCase(new Locale("ru", "RU"));
            return n.contains("бизидом") || n.contains("бизиборд");
        }

        static Product fromJson(JSONObject o) {
            Product p = new Product();
            p.id = o.optInt("id");
            p.name = o.optString("name", "");
            p.slug = o.optString("slug", "");
            p.sku = o.optString("sku", "");
            p.permalink = o.optString("permalink", "");
            p.summary = o.optString("summary", "");
            p.shortDescription = o.optString("short_description", "");
            p.description = o.optString("description", "");
            p.productType = o.optString("product_type", "standard");
            JSONObject customAmount = o.optJSONObject("custom_amount");
            if (customAmount != null) {
                p.customAmountEnabled = customAmount.optBoolean("enabled", false);
                p.customMinRaw = customAmount.optString("minimum", "0");
                p.customMaxRaw = customAmount.optString("maximum", "0");
                p.customSuggestedRaw = customAmount.optString("suggested", "0");
            }
            p.onSale = o.optBoolean("on_sale", false);
            p.purchasable = o.optBoolean("is_purchasable", true);
            p.inStock = o.optBoolean("is_in_stock", true);
            JSONObject prices = o.optJSONObject("prices");
            if (prices != null) {
                p.priceRaw = prices.optString("price", "0");
                p.regularPriceRaw = prices.optString("regular_price", p.priceRaw);
                p.salePriceRaw = prices.optString("sale_price", p.priceRaw);
                p.currency = prices.optString("currency_code", "RUB");
                p.currencySymbol = prices.optString("currency_symbol", "₽");
                p.minorUnit = prices.optInt("currency_minor_unit", 2);
            }
            JSONArray imgs = o.optJSONArray("images");
            if (imgs != null) {
                for (int i = 0; i < imgs.length(); i++) {
                    JSONObject img = imgs.optJSONObject(i);
                    if (img == null) continue;
                    String src = img.optString("src", "");
                    if (!src.isEmpty()) p.images.add(src);
                }
            }
            JSONArray cats = o.optJSONArray("categories");
            if (cats != null) {
                for (int i = 0; i < cats.length(); i++) {
                    JSONObject c = cats.optJSONObject(i);
                    if (c != null) p.categories.add(Category.fromJson(c));
                }
            }
            JSONArray attrs = o.optJSONArray("attributes");
            if (attrs != null) {
                for (int i = 0; i < attrs.length(); i++) {
                    JSONObject a = attrs.optJSONObject(i);
                    if (a != null) p.attributes.add(Attribute.fromJson(a));
                }
            }
            return p;
        }
    }

    static final class Category {
        int id;
        String name = "";
        String slug = "";
        String description = "";
        String image = "";
        int count;

        static Category fromJson(JSONObject o) {
            Category c = new Category();
            c.id = o.optInt("id");
            c.name = o.optString("name", "");
            c.slug = o.optString("slug", "");
            c.description = o.optString("description", "");
            c.count = o.optInt("count", 0);
            JSONObject image = o.optJSONObject("image");
            if (image != null) c.image = image.optString("src", "");
            return c;
        }
    }

    static final class Attribute {
        String name = "";
        final List<String> terms = new ArrayList<>();

        static Attribute fromJson(JSONObject o) {
            Attribute a = new Attribute();
            a.name = o.optString("name", "");
            JSONArray terms = o.optJSONArray("terms");
            if (terms != null) {
                for (int i = 0; i < terms.length(); i++) {
                    Object term = terms.opt(i);
                    if (term instanceof JSONObject) {
                        String name = ((JSONObject) term).optString("name", ((JSONObject) term).optString("slug", ""));
                        if (!name.isEmpty()) a.terms.add(name);
                    } else {
                        String value = terms.optString(i, "");
                        if (!value.isEmpty()) a.terms.add(value);
                    }
                }
            }
            return a;
        }
    }

    static final class CartItem {
        String key = "";
        int id;
        int quantity = 1;
        String name = "";
        String sku = "";
        String image = "";
        String priceRaw = "0";
        String lineTotalRaw = "0";
        int minorUnit = 2;
        String currencySymbol = "₽";
        String childName = "";

        String priceText() { return formatMinor(priceRaw, minorUnit, currencySymbol); }
        String totalText() { return formatMinor(lineTotalRaw, minorUnit, currencySymbol); }

        static CartItem fromJson(JSONObject o) {
            CartItem item = new CartItem();
            item.key = o.optString("key", "");
            item.id = o.optInt("id");
            item.quantity = o.optInt("quantity", 1);
            item.name = o.optString("name", "");
            item.sku = o.optString("sku", "");
            JSONArray images = o.optJSONArray("images");
            if (images != null && images.length() > 0) {
                JSONObject img = images.optJSONObject(0);
                if (img != null) item.image = img.optString("thumbnail", img.optString("src", ""));
            }
            JSONObject prices = o.optJSONObject("prices");
            if (prices != null) {
                item.priceRaw = prices.optString("price", "0");
                item.minorUnit = prices.optInt("currency_minor_unit", 2);
                item.currencySymbol = prices.optString("currency_symbol", "₽");
            }
            JSONObject totals = o.optJSONObject("totals");
            if (totals != null) {
                item.lineTotalRaw = totals.optString("line_total", item.priceRaw);
                item.minorUnit = totals.optInt("currency_minor_unit", item.minorUnit);
                item.currencySymbol = totals.optString("currency_symbol", item.currencySymbol);
            }
            JSONArray itemData = o.optJSONArray("item_data");
            if (itemData != null) {
                for (int i = 0; i < itemData.length(); i++) {
                    JSONObject d = itemData.optJSONObject(i);
                    if (d == null) continue;
                    String key = plain(d.optString("key", "")).toLowerCase(new Locale("ru", "RU"));
                    if (key.contains("имя") || key.contains("крыши") || key.contains("ребён")) {
                        item.childName = plain(d.optString("value", ""));
                    }
                }
            }
            return item;
        }
    }

    static final class ShippingRate {
        int packageId;
        String rateId = "";
        String name = "";
        String description = "";
        String priceRaw = "0";
        int minorUnit = 2;
        String currencySymbol = "₽";
        boolean selected;

        String priceText() { return formatMinor(priceRaw, minorUnit, currencySymbol); }
    }

    static final class Cart {
        final List<CartItem> items = new ArrayList<>();
        final List<ShippingRate> shippingRates = new ArrayList<>();
        final List<String> paymentMethods = new ArrayList<>();
        String totalPriceRaw = "0";
        String subtotalRaw = "0";
        String totalShippingRaw = "0";
        int minorUnit = 2;
        String currencySymbol = "₽";
        int itemsCount;
        boolean needsShipping = true;

        String totalText() { return formatMinor(totalPriceRaw, minorUnit, currencySymbol); }
        String subtotalText() { return formatMinor(subtotalRaw, minorUnit, currencySymbol); }
        String shippingText() { return formatMinor(totalShippingRaw, minorUnit, currencySymbol); }

        static Cart fromJson(JSONObject o) {
            Cart cart = new Cart();
            JSONArray items = o.optJSONArray("items");
            if (items != null) {
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    if (item != null) cart.items.add(CartItem.fromJson(item));
                }
            }
            cart.itemsCount = o.optInt("items_count", 0);
            cart.needsShipping = o.optBoolean("needs_shipping", true);
            JSONObject totals = o.optJSONObject("totals");
            if (totals != null) {
                cart.totalPriceRaw = totals.optString("total_price", "0");
                cart.subtotalRaw = totals.optString("total_items", totals.optString("total_items_tax", "0"));
                cart.totalShippingRaw = totals.optString("total_shipping", "0");
                cart.minorUnit = totals.optInt("currency_minor_unit", 2);
                cart.currencySymbol = totals.optString("currency_symbol", "₽");
            }
            JSONArray methods = o.optJSONArray("payment_methods");
            if (methods != null) for (int i = 0; i < methods.length(); i++) cart.paymentMethods.add(methods.optString(i, ""));
            JSONArray packages = o.optJSONArray("shipping_rates");
            if (packages != null) {
                for (int i = 0; i < packages.length(); i++) {
                    JSONObject pkg = packages.optJSONObject(i);
                    if (pkg == null) continue;
                    int packageId = pkg.optInt("package_id", i);
                    JSONArray rates = pkg.optJSONArray("shipping_rates");
                    if (rates == null) continue;
                    for (int j = 0; j < rates.length(); j++) {
                        JSONObject r = rates.optJSONObject(j);
                        if (r == null) continue;
                        ShippingRate rate = new ShippingRate();
                        rate.packageId = packageId;
                        rate.rateId = r.optString("rate_id", "");
                        rate.name = r.optString("name", "Доставка");
                        rate.description = r.optString("description", "");
                        rate.priceRaw = r.optString("price", "0");
                        rate.minorUnit = r.optInt("currency_minor_unit", cart.minorUnit);
                        rate.currencySymbol = r.optString("currency_symbol", cart.currencySymbol);
                        rate.selected = r.optBoolean("selected", false);
                        cart.shippingRates.add(rate);
                    }
                }
            }
            return cart;
        }
    }

    static final class CheckoutResult {
        int orderId;
        String orderNumber = "";
        String orderKey = "";
        String status = "";
        String paymentStatus = "";
        String redirectUrl = "";

        static CheckoutResult fromJson(JSONObject o) {
            CheckoutResult result = new CheckoutResult();
            result.orderId = o.optInt("order_id");
            result.orderNumber = o.optString("order_number", String.valueOf(result.orderId));
            result.orderKey = o.optString("order_key", "");
            result.status = o.optString("status", "");
            JSONObject payment = o.optJSONObject("payment_result");
            if (payment != null) {
                result.paymentStatus = payment.optString("payment_status", "");
                result.redirectUrl = payment.optString("redirect_url", "");
            }
            return result;
        }
    }
}
