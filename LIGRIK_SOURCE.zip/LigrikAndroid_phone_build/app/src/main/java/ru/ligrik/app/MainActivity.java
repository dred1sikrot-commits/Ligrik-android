package ru.ligrik.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.LinkMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(31, 77, 58);
    private static final int DEEP_GREEN = Color.rgb(23, 57, 43);
    private static final int CREAM = Color.rgb(248, 243, 234);
    private static final int PAPER = Color.rgb(255, 253, 249);
    private static final int SOFT_GREEN = Color.rgb(232, 239, 234);
    private static final int MUTED = Color.rgb(103, 117, 108);
    private static final int BORDER = Color.rgb(226, 223, 216);
    private static final int RED = Color.rgb(195, 61, 74);

    private static final String PREFS = "ligrik_native";
    private static final String PREF_FAVORITES = "favorite_ids";
    private static final String PREF_RECENT_ORDERS = "recent_orders";
    private static final String PREF_FIRST = "profile_first";
    private static final String PREF_LAST = "profile_last";
    private static final String PREF_PHONE = "profile_phone";
    private static final String PREF_EMAIL = "profile_email";
    private static final String PREF_CITY = "profile_city";
    private static final String PREF_REGION = "profile_region";
    private static final String PREF_ADDRESS = "profile_address";
    private static final String PREF_POSTCODE = "profile_postcode";
    private static final String ROOF_PREFIX = "roof_name_";

    private static final String LOGO_URL = "https://ligrik.ru/wp-content/uploads/2026/07/ligrik-logo-kubiki.webp";
    private static final String MASCOT_URL = "https://ligrik.ru/wp-content/uploads/2026/07/ligrik-otdelno-ot-logo.webp";
    private static final String IMG_SMALL = "https://ligrik.ru/wp-content/uploads/2026/07/malenkie-bizidomiki-1.webp";
    private static final String IMG_MEDIUM = "https://ligrik.ru/wp-content/uploads/2026/07/srednie-bizidomiki.webp";
    private static final String IMG_LARGE = "https://ligrik.ru/wp-content/uploads/2026/07/bolshie-bizidomiki.webp";
    private static final String IMG_HUGE = "https://ligrik.ru/wp-content/uploads/2026/07/ogromnye-bizidomiki.webp";

    private StoreApiClient api;
    private SharedPreferences prefs;
    private FrameLayout content;
    private LinearLayout toolbar;
    private TextView toolbarTitle;
    private ImageButton backButton;
    private ImageButton actionButton;
    private ProgressBar progress;
    private LinearLayout bottomNav;
    private View statusSpacer;
    private View navSpacer;
    private TextView cartBadge;
    private View paymentOverlay;
    private final List<NavItem> navItems = new ArrayList<>();
    private String screen = "home";
    private StoreModels.Product currentProduct;
    private StoreModels.Cart currentCart;
    private String catalogQuery = "";
    private String catalogCategory = "";
    private String catalogCategoryTitle = "Все";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        api = new StoreApiClient(this);
        buildShell();
        showHome();
        refreshCartBadge();
        handlePaymentReturnIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handlePaymentReturnIntent(intent);
    }

    private void buildShell() {
        Window w = getWindow();
        w.setStatusBarColor(CREAM);
        w.setNavigationBarColor(CREAM);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(CREAM);

        statusSpacer = new View(this);
        statusSpacer.setBackgroundColor(CREAM);
        root.addView(statusSpacer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0));

        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(6), 0, dp(6), 0);
        toolbar.setBackgroundColor(GREEN);
        root.addView(toolbar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));

        backButton = new ImageButton(this);
        backButton.setImageResource(R.drawable.ic_back);
        backButton.setColorFilter(Color.WHITE);
        backButton.setBackgroundColor(Color.TRANSPARENT);
        backButton.setContentDescription("Назад");
        backButton.setOnClickListener(v -> goBack());
        toolbar.addView(backButton, new LinearLayout.LayoutParams(dp(50), dp(50)));

        toolbarTitle = text("Лигрик", 21, Color.WHITE, true);
        toolbarTitle.setGravity(Gravity.CENTER);
        toolbar.addView(toolbarTitle, new LinearLayout.LayoutParams(0, dp(58), 1f));

        actionButton = new ImageButton(this);
        actionButton.setImageResource(R.drawable.ic_favorite);
        actionButton.setColorFilter(Color.WHITE);
        actionButton.setBackgroundColor(Color.TRANSPARENT);
        actionButton.setVisibility(View.INVISIBLE);
        toolbar.addView(actionButton, new LinearLayout.LayoutParams(dp(50), dp(50)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)));

        content = new FrameLayout(this);
        content.setBackgroundColor(CREAM);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        bottomNav = new LinearLayout(this);
        bottomNav.setOrientation(LinearLayout.HORIZONTAL);
        bottomNav.setGravity(Gravity.CENTER);
        bottomNav.setPadding(dp(3), dp(3), dp(3), dp(3));
        bottomNav.setBackgroundColor(PAPER);
        root.addView(bottomNav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(76)));

        addNav("Главная", R.drawable.ic_home, "home");
        addNav("Каталог", R.drawable.ic_catalog, "catalog");
        addNav("Избранное", R.drawable.ic_favorite, "favorites");
        addNav("Корзина", R.drawable.ic_cart, "cart");
        addNav("Профиль", R.drawable.ic_account, "profile");

        navSpacer = new View(this);
        navSpacer.setBackgroundColor(PAPER);
        root.addView(navSpacer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0));

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            int left = insets.getSystemWindowInsetLeft();
            int right = insets.getSystemWindowInsetRight();
            LinearLayout.LayoutParams topLp = (LinearLayout.LayoutParams) statusSpacer.getLayoutParams();
            topLp.height = top;
            statusSpacer.setLayoutParams(topLp);
            LinearLayout.LayoutParams bottomLp = (LinearLayout.LayoutParams) navSpacer.getLayoutParams();
            bottomLp.height = bottom;
            navSpacer.setLayoutParams(bottomLp);
            toolbar.setPadding(dp(6) + left, 0, dp(6) + right, 0);
            bottomNav.setPadding(dp(3) + left, dp(3), dp(3) + right, dp(3));
            return insets;
        });

        setContentView(root);
        root.requestApplyInsets();
    }

    private void addNav(String label, int iconRes, String target) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(2), dp(5), dp(2), dp(4));
        item.setTag(target);

        FrameLayout iconFrame = new FrameLayout(this);
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(MUTED);
        icon.setTag("icon");
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(dp(27), dp(27), Gravity.CENTER);
        iconFrame.addView(icon, ip);

        if ("cart".equals(target)) {
            cartBadge = text("", 9, Color.WHITE, true);
            cartBadge.setGravity(Gravity.CENTER);
            cartBadge.setBackground(roundRect(RED, dp(20), 0, 0));
            cartBadge.setVisibility(View.GONE);
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.TOP | Gravity.RIGHT);
            bp.setMargins(0, 0, dp(3), 0);
            iconFrame.addView(cartBadge, bp);
        }
        item.addView(iconFrame, new LinearLayout.LayoutParams(dp(44), dp(31)));

        TextView labelView = text(label, 11, MUTED, false);
        labelView.setGravity(Gravity.CENTER);
        labelView.setTag("label");
        item.addView(labelView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));
        item.setOnClickListener(v -> navigateBottom(target));
        bottomNav.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        navItems.add(new NavItem(target, item, icon, labelView));
    }

    private void navigateBottom(String target) {
        if ("home".equals(target)) showHome();
        else if ("catalog".equals(target)) { catalogQuery = ""; catalogCategory = ""; catalogCategoryTitle = "Все"; showCatalog(); }
        else if ("favorites".equals(target)) showFavorites();
        else if ("cart".equals(target)) showCart();
        else if ("profile".equals(target)) showProfile();
    }

    private void setShell(String newScreen, String title, boolean showToolbar, boolean showBack, String selectedTab) {
        screen = newScreen;
        toolbar.setVisibility(showToolbar ? View.VISIBLE : View.GONE);
        backButton.setVisibility(showBack ? View.VISIBLE : View.INVISIBLE);
        toolbarTitle.setText(title == null ? "Лигрик" : title);
        actionButton.setVisibility(View.INVISIBLE);
        bottomNav.setVisibility(View.VISIBLE);
        setStatusStyle(!showToolbar);
        selectNav(selectedTab);
        progress.setVisibility(View.GONE);
    }

    private void setStatusStyle(boolean light) {
        getWindow().setStatusBarColor(light ? CREAM : GREEN);
        if (statusSpacer != null) statusSpacer.setBackgroundColor(light ? CREAM : GREEN);
        if (navSpacer != null) navSpacer.setBackgroundColor(PAPER);
        int flags = getWindow().getDecorView().getSystemUiVisibility();
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    private void selectNav(String target) {
        for (NavItem item : navItems) {
            boolean selected = item.target.equals(target);
            item.icon.setColorFilter(selected ? GREEN : Color.rgb(135, 151, 142));
            item.label.setTextColor(selected ? GREEN : Color.rgb(135, 151, 142));
            item.label.setTypeface(Typeface.DEFAULT, selected ? Typeface.BOLD : Typeface.NORMAL);
            item.root.setBackground(selected ? roundRect(SOFT_GREEN, dp(24), 0, 0) : null);
        }
    }

    private void replaceContent(View view) {
        content.removeAllViews();
        content.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    // ---------- HOME ----------

    private void showHome() {
        currentProduct = null;
        setShell("home", "Лигрик", false, false, "home");
        ScrollView scroll = pageScroll();
        LinearLayout body = pageBody(scroll);
        body.setPadding(dp(18), dp(16), dp(18), dp(28));

        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setImageResource(R.drawable.ic_ligrik);
        body.addView(logo, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(92)));
        RemoteImageLoader.load(this, logo, LOGO_URL);

        TextView eyebrow = text("● ИГРУШКИ ДЛЯ СЧАСТЛИВОГО ДЕТСТВА", 11, GREEN, true);
        eyebrow.setGravity(Gravity.CENTER);
        eyebrow.setLetterSpacing(0.05f);
        body.addView(eyebrow, margin(matchWrap(), 0, 8, 0, 0));

        TextView hero = text("Растём через игру", 31, DEEP_GREEN, true);
        hero.setGravity(Gravity.CENTER);
        body.addView(hero, margin(matchWrap(), 0, 12, 0, 0));

        TextView sub = text("Развивающие деревянные игрушки, созданные с заботой о каждом этапе детства.", 16, MUTED, false);
        sub.setGravity(Gravity.CENTER);
        sub.setLineSpacing(dp(3), 1f);
        body.addView(sub, margin(matchWrap(), dp(12), 10, dp(12), 0));

        LinearLayout gift = new LinearLayout(this);
        gift.setOrientation(LinearLayout.HORIZONTAL);
        gift.setGravity(Gravity.CENTER_VERTICAL);
        gift.setPadding(dp(16), dp(14), dp(16), dp(14));
        gift.setBackground(roundRect(SOFT_GREEN, dp(22), 0, 0));
        TextView emoji = text("🎁", 26, DEEP_GREEN, false);
        gift.addView(emoji, new LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout giftText = new LinearLayout(this);
        giftText.setOrientation(LinearLayout.VERTICAL);
        giftText.addView(text("Именная крыша — в подарок", 17, DEEP_GREEN, true));
        giftText.addView(text("Укажите имя ребёнка при заказе — изготовим бесплатно", 13, MUTED, false));
        gift.addView(giftText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        body.addView(gift, margin(matchWrap(), 0, 20, 0, 0));

        Button catalog = primaryButton("Смотреть весь каталог");
        catalog.setOnClickListener(v -> { catalogQuery = ""; catalogCategory = ""; catalogCategoryTitle = "Все"; showCatalog(); });
        body.addView(catalog, margin(matchWrap(), 0, 18, 0, 0));

        body.addView(sectionTitle("Выберите размер"), margin(matchWrap(), 0, 10, 0, 0));
        body.addView(text("Категории бизидомиков «Лигрик»", 14, MUTED, false));
        body.addView(categoryCard("Маленькие бизидомики", "Компактные модели", IMG_SMALL, "malenkie-bizidomiki"), margin(matchWrap(), 0, 16, 0, 0));
        body.addView(categoryCard("Средние бизидомики", "Больше игровых элементов", IMG_MEDIUM, "srednie-bizidomiki"), margin(matchWrap(), 0, 12, 0, 0));
        body.addView(categoryCard("Большие бизидомики", "Много занятий на каждой стороне", IMG_LARGE, "bolshie-bizidomiki"), margin(matchWrap(), 0, 12, 0, 0));
        body.addView(categoryCard("Огромные бизидомики", "Большой развивающий центр", IMG_HUGE, "ogromnye-bizidomiki"), margin(matchWrap(), 0, 12, 0, 0));

        body.addView(sectionTitle("Популярные игрушки"), margin(matchWrap(), 0, 24, 0, 0));
        LinearLayout popular = new LinearLayout(this);
        popular.setOrientation(LinearLayout.VERTICAL);
        popular.addView(loadingBlock("Загружаем товары…"));
        body.addView(popular, matchWrap());
        api.getProducts("", "", 6, new StoreApiClient.Callback<List<StoreModels.Product>>() {
            @Override public void onSuccess(List<StoreModels.Product> products) {
                if (!"home".equals(screen)) return;
                popular.removeAllViews();
                if (products.isEmpty()) popular.addView(infoBlock("Каталог пока пуст."));
                else for (StoreModels.Product product : products) popular.addView(productCard(product), margin(matchWrap(), 0, 10, 0, 0));
            }
            @Override public void onError(String message) {
                if (!"home".equals(screen)) return;
                popular.removeAllViews();
                popular.addView(errorBlock(message, v -> showHome()));
            }
        });
        replaceContent(scroll);
    }

    private View categoryCard(String title, String subtitle, String imageUrl, String slug) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12), dp(12), dp(14), dp(12));
        card.setBackground(roundRect(Color.WHITE, dp(22), 0, 0));
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setBackground(roundRect(SOFT_GREEN, dp(16), 0, 0));
        card.addView(image, new LinearLayout.LayoutParams(dp(122), dp(105)));
        if (imageUrl != null && !imageUrl.isEmpty()) RemoteImageLoader.load(this, image, imageUrl);
        else { image.setImageResource(R.drawable.ic_ligrik); image.setPadding(dp(32), dp(24), dp(32), dp(24)); }
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.setPadding(dp(14), 0, 0, 0);
        txt.addView(text(title, 19, DEEP_GREEN, true));
        txt.addView(text(subtitle, 13, MUTED, false), margin(matchWrap(), 0, 5, 0, 0));
        txt.addView(text("Смотреть →", 14, GREEN, true), margin(matchWrap(), 0, 10, 0, 0));
        card.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.setOnClickListener(v -> {
            catalogQuery = "";
            catalogCategory = slug;
            catalogCategoryTitle = title;
            showCatalog();
        });
        return card;
    }

    // ---------- CATALOG ----------

    private void showCatalog() {
        currentProduct = null;
        setShell("catalog", catalogCategoryTitle.equals("Все") ? "Каталог" : catalogCategoryTitle, true, false, "catalog");
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(CREAM);
        root.setPadding(dp(14), dp(12), dp(14), 0);

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);
        EditText search = input("Найти игрушку");
        search.setSingleLine(true);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setText(catalogQuery);
        searchRow.addView(search, new LinearLayout.LayoutParams(0, dp(52), 1f));
        Button searchBtn = smallButton("Найти");
        searchRow.addView(searchBtn, margin(new LinearLayout.LayoutParams(dp(86), dp(52)), dp(8), 0, 0, 0));
        root.addView(searchRow, matchWrap());

        HorizontalScrollView chipsScroll = new HorizontalScrollView(this);
        chipsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setPadding(0, dp(10), 0, dp(10));
        chipsScroll.addView(chips);
        addCategoryChip(chips, "Все", "");
        addCategoryChip(chips, "Маленькие", "malenkie-bizidomiki");
        addCategoryChip(chips, "Средние", "srednie-bizidomiki");
        addCategoryChip(chips, "Большие", "bolshie-bizidomiki");
        addCategoryChip(chips, "Огромные", "ogromnye-bizidomiki");
        root.addView(chipsScroll, matchWrap());

        ScrollView scroll = pageScroll();
        LinearLayout list = pageBody(scroll);
        list.setPadding(0, dp(2), 0, dp(22));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        replaceContent(root);

        View.OnClickListener doSearch = v -> {
            catalogQuery = search.getText().toString().trim();
            loadCatalog(list);
        };
        searchBtn.setOnClickListener(doSearch);
        search.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { doSearch.onClick(v); return true; }
            return false;
        });
        loadCatalog(list);
    }

    private void addCategoryChip(LinearLayout row, String label, String slug) {
        TextView chip = text(label, 13, catalogCategory.equals(slug) ? Color.WHITE : GREEN, true);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(15), dp(9), dp(15), dp(9));
        chip.setBackground(roundRect(catalogCategory.equals(slug) ? GREEN : Color.WHITE, dp(20), BORDER, dp(1)));
        chip.setOnClickListener(v -> {
            catalogCategory = slug;
            catalogCategoryTitle = label;
            showCatalog();
        });
        row.addView(chip, margin(wrap(), 0, 0, 8, 0));
    }

    private void loadCatalog(LinearLayout list) {
        list.removeAllViews();
        list.addView(loadingBlock("Загружаем каталог…"));
        progress.setVisibility(View.VISIBLE);
        api.getProducts(catalogQuery, catalogCategory, 100, new StoreApiClient.Callback<List<StoreModels.Product>>() {
            @Override public void onSuccess(List<StoreModels.Product> products) {
                if (!"catalog".equals(screen)) return;
                progress.setVisibility(View.GONE);
                list.removeAllViews();
                if (products.isEmpty()) {
                    list.addView(emptyBlock("Ничего не нашли", "Попробуйте изменить поиск или выбрать другую категорию."));
                    return;
                }
                TextView count = text("Найдено: " + products.size(), 12, MUTED, false);
                list.addView(count, margin(matchWrap(), dp(4), 2, 0, 0));
                for (StoreModels.Product p : products) list.addView(productCard(p), margin(matchWrap(), 0, 10, 0, 0));
            }
            @Override public void onError(String message) {
                if (!"catalog".equals(screen)) return;
                progress.setVisibility(View.GONE);
                list.removeAllViews();
                list.addView(errorBlock(message, v -> loadCatalog(list)));
            }
        });
    }

    private View productCard(StoreModels.Product product) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.TOP);
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        card.setBackground(roundRect(Color.WHITE, dp(20), 0, 0));
        card.setOnClickListener(v -> showProduct(product));

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setAdjustViewBounds(true);
        image.setPadding(dp(3), dp(3), dp(3), dp(3));
        image.setBackground(roundRect(Color.WHITE, dp(15), BORDER, dp(1)));
        card.addView(image, new LinearLayout.LayoutParams(dp(128), dp(154)));
        if (!product.primaryImage().isEmpty()) RemoteImageLoader.load(this, image, product.primaryImage());

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setPadding(dp(12), dp(2), 0, 0);
        TextView name = text(product.name, 17, DEEP_GREEN, true);
        name.setMaxLines(3);
        right.addView(name, matchWrap());
        if (!product.sku.isEmpty()) right.addView(text("Арт. " + product.sku, 11, MUTED, false), margin(matchWrap(), 0, 5, 0, 0));
        right.addView(text(product.priceText(), 18, GREEN, true), margin(matchWrap(), 0, 9, 0, 0));
        TextView open = text("Подробнее →", 13, GREEN, true);
        right.addView(open, margin(matchWrap(), 0, 8, 0, 0));
        card.addView(right, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView heart = text(isFavorite(product.id) ? "♥" : "♡", 28, isFavorite(product.id) ? RED : MUTED, false);
        heart.setGravity(Gravity.CENTER);
        heart.setOnClickListener(v -> {
            toggleFavorite(product.id);
            heart.setText(isFavorite(product.id) ? "♥" : "♡");
            heart.setTextColor(isFavorite(product.id) ? RED : MUTED);
        });
        card.addView(heart, new LinearLayout.LayoutParams(dp(42), dp(48)));
        return card;
    }

    // ---------- PRODUCT ----------

    private void showProduct(StoreModels.Product product) {
        currentProduct = product;
        setShell("product", "Товар", true, true, "catalog");
        actionButton.setVisibility(View.VISIBLE);
        refreshToolbarFavorite();
        actionButton.setOnClickListener(v -> {
            toggleFavorite(product.id);
            refreshToolbarFavorite();
        });

        ScrollView scroll = pageScroll();
        LinearLayout body = pageBody(scroll);
        body.setPadding(dp(14), dp(14), dp(14), dp(28));

        HorizontalScrollView gallery = new HorizontalScrollView(this);
        gallery.setHorizontalScrollBarEnabled(false);
        LinearLayout images = new LinearLayout(this);
        images.setOrientation(LinearLayout.HORIZONTAL);
        gallery.addView(images);
        if (product.images.isEmpty()) {
            ImageView placeholder = new ImageView(this);
            placeholder.setImageResource(R.drawable.ic_ligrik);
            images.addView(placeholder, new LinearLayout.LayoutParams(dp(300), dp(300)));
        } else {
            for (String url : product.images) {
                ImageView image = new ImageView(this);
                image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                image.setAdjustViewBounds(true);
                image.setPadding(dp(3), dp(3), dp(3), dp(3));
                image.setBackground(roundRect(Color.WHITE, dp(20), BORDER, dp(1)));
                images.addView(image, margin(new LinearLayout.LayoutParams(dp(315), dp(420)), 0, 0, 10, 0));
                RemoteImageLoader.load(this, image, url);
            }
        }
        body.addView(gallery, matchWrap());

        body.addView(text(product.name, 26, DEEP_GREEN, true), margin(matchWrap(), 0, 18, 0, 0));
        body.addView(text(product.priceText(), 25, GREEN, true), margin(matchWrap(), 0, 10, 0, 0));
        if (!product.sku.isEmpty()) body.addView(text("Артикул: " + product.sku, 12, MUTED, false));

        if (!product.attributes.isEmpty()) {
            LinearLayout specs = new LinearLayout(this);
            specs.setOrientation(LinearLayout.VERTICAL);
            specs.setPadding(dp(14), dp(12), dp(14), dp(12));
            specs.setBackground(roundRect(SOFT_GREEN, dp(18), 0, 0));
            for (StoreModels.Attribute a : product.attributes) {
                if (a.name.isEmpty() || a.terms.isEmpty()) continue;
                specs.addView(text(a.name + ": " + join(a.terms, ", "), 13, DEEP_GREEN, false), margin(matchWrap(), 0, 4, 0, 0));
            }
            body.addView(specs, margin(matchWrap(), 0, 14, 0, 0));
        }

        EditText certificateAmount = null;
        if (product.isGiftCertificate()) {
            LinearLayout cert = new LinearLayout(this);
            cert.setOrientation(LinearLayout.VERTICAL);
            cert.setPadding(dp(16), dp(15), dp(16), dp(15));
            cert.setBackground(roundRect(Color.rgb(239, 245, 240), dp(20), 0, 0));
            cert.addView(text("🎁  Выберите сумму сертификата", 18, DEEP_GREEN, true));
            cert.addView(text("Получатель сможет использовать сертификат на товары «Лигрик». Сумму определяете вы.", 13, MUTED, false), margin(matchWrap(), 0, 7, 0, 0));

            certificateAmount = input("Введите сумму, ₽");
            certificateAmount.setSingleLine(true);
            certificateAmount.setInputType(InputType.TYPE_CLASS_NUMBER);
            certificateAmount.setFilters(new InputFilter[]{new InputFilter.LengthFilter(7)});
            long suggestedRub = Math.max(1, product.customSuggested() / 100L);
            certificateAmount.setText(String.valueOf(suggestedRub));

            LinearLayout quick = new LinearLayout(this);
            quick.setOrientation(LinearLayout.HORIZONTAL);
            quick.setGravity(Gravity.CENTER_VERTICAL);
            long[] presets = new long[]{3000L, 5000L, 10000L};
            for (long rub : presets) {
                Button q = tinyButton(String.format(new Locale("ru", "RU"), "%,d ₽", rub).replace(',', ' '));
                q.setTextSize(12);
                q.setAllCaps(false);
                q.setEnabled(rub * 100L >= product.customMin() && rub * 100L <= product.customMax());
                EditText amountTarget = certificateAmount;
                q.setOnClickListener(v -> amountTarget.setText(String.valueOf(rub)));
                quick.addView(q, new LinearLayout.LayoutParams(0, dp(46), 1f));
            }
            cert.addView(quick, margin(matchWrap(), 0, 10, 0, 0));
            cert.addView(certificateAmount);
            cert.addView(text("Допустимо: " + StoreModels.formatMinor(String.valueOf(product.customMin()), 2, "₽") + " — " + StoreModels.formatMinor(String.valueOf(product.customMax()), 2, "₽"), 11, MUTED, false), margin(matchWrap(), 0, 6, 0, 0));
            body.addView(cert, margin(matchWrap(), 0, 18, 0, 0));
        }

        EditText roofName = null;
        CheckBox wantPersonalRoof = null;
        if (product.supportsPersonalRoof()) {
            LinearLayout gift = new LinearLayout(this);
            gift.setOrientation(LinearLayout.VERTICAL);
            gift.setPadding(dp(16), dp(15), dp(16), dp(15));
            gift.setBackground(roundRect(Color.rgb(239, 245, 240), dp(20), 0, 0));
            gift.addView(text("🎁  Именная крыша — в подарок", 18, DEEP_GREEN, true));
            int max = roofMaxChars(product);
            gift.addView(text("Подарочная опция по желанию. Отметьте её только если хотите крышу с именем ребёнка.", 13, MUTED, false), margin(matchWrap(), 0, 7, 0, 0));

            String savedRoofName = prefs.getString(ROOF_PREFIX + product.id, "");
            wantPersonalRoof = new CheckBox(this);
            wantPersonalRoof.setText("Хочу именную крышу");
            wantPersonalRoof.setTextColor(DEEP_GREEN);
            wantPersonalRoof.setTextSize(15);
            wantPersonalRoof.setChecked(!savedRoofName.isEmpty());
            gift.addView(wantPersonalRoof, margin(matchWrap(), 0, 8, 0, 0));

            roofName = input("Имя ребёнка, до " + max + " букв");
            roofName.setSingleLine(true);
            roofName.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(max)});
            roofName.setText(savedRoofName);
            roofName.setVisibility(wantPersonalRoof.isChecked() ? View.VISIBLE : View.GONE);
            EditText roofNameForToggle = roofName;
            wantPersonalRoof.setOnCheckedChangeListener((buttonView, isChecked) -> {
                roofNameForToggle.setVisibility(isChecked ? View.VISIBLE : View.GONE);
                if (isChecked) roofNameForToggle.requestFocus();
                else roofNameForToggle.setError(null);
            });
            gift.addView(roofName, margin(matchWrap(), 0, 10, 0, 0));
            body.addView(gift, margin(matchWrap(), 0, 18, 0, 0));
        }

        Button add = primaryButton(product.inStock ? (product.isGiftCertificate() ? "Добавить сертификат в корзину" : "Добавить в корзину") : "Нет в наличии");
        add.setEnabled(product.inStock && product.purchasable);
        EditText finalRoofName = roofName;
        CheckBox finalWantPersonalRoof = wantPersonalRoof;
        EditText finalCertificateAmount = certificateAmount;
        add.setOnClickListener(v -> {
            String customAmountRaw = "";
            if (product.isGiftCertificate()) {
                String rubText = finalCertificateAmount == null ? "" : finalCertificateAmount.getText().toString().trim().replace(" ", "");
                long rub;
                try { rub = Long.parseLong(rubText); } catch (Exception e) { rub = 0L; }
                long amount = rub * 100L;
                if (amount < product.customMin() || amount > product.customMax()) {
                    if (finalCertificateAmount != null) finalCertificateAmount.setError("Введите сумму в разрешённом диапазоне");
                    showToast("Укажите сумму сертификата от " + StoreModels.formatMinor(String.valueOf(product.customMin()), 2, "₽") + " до " + StoreModels.formatMinor(String.valueOf(product.customMax()), 2, "₽"));
                    return;
                }
                customAmountRaw = String.valueOf(amount);
            }
            boolean wantsRoof = finalWantPersonalRoof != null && finalWantPersonalRoof.isChecked();
            String child = wantsRoof && finalRoofName != null ? finalRoofName.getText().toString().trim() : "";
            if (wantsRoof && child.isEmpty()) {
                // Не блокируем покупку: товар уйдёт в корзину без персонализации.
                if (finalRoofName != null) finalRoofName.setError(null);
                Toast.makeText(MainActivity.this, "Имя не указано — добавим товар без именной крыши", Toast.LENGTH_SHORT).show();
            }
            if (!child.isEmpty()) {
                prefs.edit().putString(ROOF_PREFIX + product.id, child).apply();
            } else {
                prefs.edit().remove(ROOF_PREFIX + product.id).apply();
            }
            add.setEnabled(false);
            add.setText("Добавляем…");
            api.addItem(product.id, 1, child, customAmountRaw, new StoreApiClient.Callback<StoreModels.Cart>() {
                @Override public void onSuccess(StoreModels.Cart cart) {
                    currentCart = cart;
                    updateCartBadge(cart.itemsCount);
                    add.setEnabled(true);
                    add.setText("Добавлено ✓");
                    Toast.makeText(MainActivity.this, product.isGiftCertificate() ? "Сертификат добавлен в корзину" : "Товар добавлен в корзину", Toast.LENGTH_SHORT).show();
                    add.postDelayed(() -> add.setText(product.isGiftCertificate() ? "Добавить ещё сертификат" : "Добавить ещё"), 1400);
                }
                @Override public void onError(String message) {
                    add.setEnabled(true);
                    add.setText(product.isGiftCertificate() ? "Добавить сертификат в корзину" : "Добавить в корзину");
                    showToast(message);
                }
            });
        });
        body.addView(add, margin(matchWrap(), 0, 14, 0, 0));

        Button goCart = secondaryButton("Перейти в корзину");
        goCart.setOnClickListener(v -> showCart());
        body.addView(goCart, margin(matchWrap(), 0, 10, 0, 0));

        String description = product.bodyText();
        if (!description.isEmpty()) {
            body.addView(sectionTitle("О товаре"), margin(matchWrap(), 0, 24, 0, 0));
            TextView desc = text(description, 15, Color.rgb(55, 63, 59), false);
            desc.setLineSpacing(dp(4), 1f);
            body.addView(desc, margin(matchWrap(), 0, 10, 0, 0));
        }
        replaceContent(scroll);
    }

    private int roofMaxChars(StoreModels.Product product) {
        for (StoreModels.Category c : product.categories) {
            String slug = c.slug.toLowerCase(Locale.ROOT);
            if (slug.contains("malenk")) return 5;
            if (slug.contains("sredn")) return 8;
            if (slug.contains("ogrom")) return 18;
            if (slug.contains("bolsh")) return 12;
        }
        return 18;
    }

    private void refreshToolbarFavorite() {
        if (currentProduct == null) return;
        actionButton.setImageResource(isFavorite(currentProduct.id) ? R.drawable.ic_favorite_filled : R.drawable.ic_favorite);
        actionButton.setColorFilter(isFavorite(currentProduct.id) ? Color.rgb(255, 220, 225) : Color.WHITE);
    }

    // ---------- FAVORITES ----------

    private void showFavorites() {
        currentProduct = null;
        setShell("favorites", "Избранное", true, false, "favorites");
        ScrollView scroll = pageScroll();
        LinearLayout body = pageBody(scroll);
        body.setPadding(dp(14), dp(18), dp(14), dp(28));
        body.addView(sectionTitle("Любимые игрушки"));
        body.addView(text("Сохраняйте товары сердечком и возвращайтесь к ним позже.", 14, MUTED, false), margin(matchWrap(), 0, 6, 0, 0));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list, margin(matchWrap(), 0, 18, 0, 0));
        replaceContent(scroll);

        List<Integer> ids = favoriteIds();
        if (ids.isEmpty()) {
            list.addView(emptyBlock("Пока пусто", "Откройте каталог и нажмите ♡ у понравившейся игрушки."));
            return;
        }
        list.addView(loadingBlock("Загружаем избранное…"));
        api.getProductsByIds(ids, new StoreApiClient.Callback<List<StoreModels.Product>>() {
            @Override public void onSuccess(List<StoreModels.Product> products) {
                if (!"favorites".equals(screen)) return;
                list.removeAllViews();
                if (products.isEmpty()) list.addView(emptyBlock("Пока пусто", "Добавьте товары из каталога."));
                else for (StoreModels.Product p : products) list.addView(productCard(p), margin(matchWrap(), 0, 10, 0, 0));
            }
            @Override public void onError(String message) {
                if (!"favorites".equals(screen)) return;
                list.removeAllViews();
                list.addView(errorBlock(message, v -> showFavorites()));
            }
        });
    }

    // ---------- CART ----------

    private void showCart() {
        currentProduct = null;
        setShell("cart", "Корзина", true, false, "cart");
        ScrollView scroll = pageScroll();
        LinearLayout body = pageBody(scroll);
        body.setPadding(dp(14), dp(16), dp(14), dp(28));
        body.addView(loadingBlock("Загружаем корзину…"));
        replaceContent(scroll);
        progress.setVisibility(View.VISIBLE);
        api.getCart(new StoreApiClient.Callback<StoreModels.Cart>() {
            @Override public void onSuccess(StoreModels.Cart cart) {
                if (!"cart".equals(screen)) return;
                progress.setVisibility(View.GONE);
                currentCart = cart;
                updateCartBadge(cart.itemsCount);
                renderCart(body, cart);
            }
            @Override public void onError(String message) {
                if (!"cart".equals(screen)) return;
                progress.setVisibility(View.GONE);
                body.removeAllViews();
                body.addView(errorBlock(message, v -> showCart()));
            }
        });
    }

    private void renderCart(LinearLayout body, StoreModels.Cart cart) {
        body.removeAllViews();
        if (cart.items.isEmpty()) {
            body.addView(emptyBlock("Корзина пуста", "Выберите игрушку в каталоге — она появится здесь."));
            Button go = primaryButton("Перейти в каталог");
            go.setOnClickListener(v -> showCatalog());
            body.addView(go, margin(matchWrap(), 0, 18, 0, 0));
            return;
        }
        body.addView(sectionTitle("Ваш заказ"));
        body.addView(text(cart.itemsCount + " " + pluralProducts(cart.itemsCount), 13, MUTED, false), margin(matchWrap(), 0, 4, 0, 0));
        for (StoreModels.CartItem item : cart.items) body.addView(cartItemCard(item), margin(matchWrap(), 0, 12, 0, 0));

        LinearLayout coupon = new LinearLayout(this);
        coupon.setOrientation(LinearLayout.HORIZONTAL);
        EditText code = input("Промокод");
        code.setSingleLine(true);
        coupon.addView(code, new LinearLayout.LayoutParams(0, dp(52), 1f));
        Button apply = smallButton("Применить");
        coupon.addView(apply, margin(new LinearLayout.LayoutParams(dp(112), dp(52)), dp(8), 0, 0, 0));
        apply.setOnClickListener(v -> {
            String c = code.getText().toString().trim();
            if (c.isEmpty()) return;
            apply.setEnabled(false);
            api.applyCoupon(c, new StoreApiClient.Callback<StoreModels.Cart>() {
                @Override public void onSuccess(StoreModels.Cart updated) {
                    apply.setEnabled(true);
                    currentCart = updated;
                    renderCart(body, updated);
                    showToast("Промокод применён");
                }
                @Override public void onError(String message) { apply.setEnabled(true); showToast(message); }
            });
        });
        body.addView(coupon, margin(matchWrap(), 0, 10, 0, 0));

        LinearLayout total = new LinearLayout(this);
        total.setOrientation(LinearLayout.VERTICAL);
        total.setPadding(dp(16), dp(15), dp(16), dp(15));
        total.setBackground(roundRect(Color.WHITE, dp(20), 0, 0));
        total.addView(summaryRow("Товары", cart.subtotalText(), false));
        if (!"0".equals(cart.totalShippingRaw)) total.addView(summaryRow("Доставка", cart.shippingText(), false));
        total.addView(summaryRow("Итого", cart.totalText(), true), margin(matchWrap(), 0, 10, 0, 0));
        body.addView(total, margin(matchWrap(), 0, 16, 0, 0));

        Button checkout = primaryButton("Перейти к оформлению");
        checkout.setOnClickListener(v -> showCheckout());
        body.addView(checkout, margin(matchWrap(), 0, 12, 0, 0));
    }

    private View cartItemCard(StoreModels.CartItem item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        card.setGravity(Gravity.TOP);
        card.setBackground(roundRect(Color.WHITE, dp(18), 0, 0));
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setAdjustViewBounds(true);
        image.setPadding(dp(2), dp(2), dp(2), dp(2));
        image.setBackground(roundRect(Color.WHITE, dp(13), BORDER, dp(1)));
        card.addView(image, new LinearLayout.LayoutParams(dp(95), dp(118)));
        if (!item.image.isEmpty()) RemoteImageLoader.load(this, image, item.image);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(11), 0, 0, 0);
        TextView name = text(item.name, 16, DEEP_GREEN, true);
        info.addView(name);
        String child = item.childName;
        if (child.isEmpty()) child = prefs.getString(ROOF_PREFIX + item.id, "");
        if (!child.isEmpty()) info.addView(text("Именная крыша: " + child, 12, MUTED, false), margin(matchWrap(), 0, 5, 0, 0));
        info.addView(text(item.totalText(), 16, GREEN, true), margin(matchWrap(), 0, 7, 0, 0));

        LinearLayout qty = new LinearLayout(this);
        qty.setOrientation(LinearLayout.HORIZONTAL);
        qty.setGravity(Gravity.CENTER_VERTICAL);
        Button minus = tinyButton("−");
        TextView count = text(String.valueOf(item.quantity), 15, DEEP_GREEN, true);
        count.setGravity(Gravity.CENTER);
        Button plus = tinyButton("+");
        Button remove = tinyButton("×");
        qty.addView(minus, new LinearLayout.LayoutParams(dp(42), dp(42)));
        qty.addView(count, new LinearLayout.LayoutParams(dp(48), dp(42)));
        qty.addView(plus, new LinearLayout.LayoutParams(dp(42), dp(42)));
        qty.addView(remove, margin(new LinearLayout.LayoutParams(dp(42), dp(42)), dp(8), 0, 0, 0));
        info.addView(qty, margin(matchWrap(), 0, 8, 0, 0));
        card.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        minus.setOnClickListener(v -> {
            if (item.quantity <= 1) return;
            changeCartItem(item, item.quantity - 1);
        });
        plus.setOnClickListener(v -> changeCartItem(item, item.quantity + 1));
        remove.setOnClickListener(v -> api.removeItem(item.key, cartCallback()));
        return card;
    }

    private void changeCartItem(StoreModels.CartItem item, int quantity) {
        progress.setVisibility(View.VISIBLE);
        api.updateItem(item.key, quantity, cartCallback());
    }

    private StoreApiClient.Callback<StoreModels.Cart> cartCallback() {
        return new StoreApiClient.Callback<StoreModels.Cart>() {
            @Override public void onSuccess(StoreModels.Cart cart) {
                progress.setVisibility(View.GONE);
                currentCart = cart;
                updateCartBadge(cart.itemsCount);
                if ("cart".equals(screen)) showCart();
            }
            @Override public void onError(String message) { progress.setVisibility(View.GONE); showToast(message); }
        };
    }

    // ---------- CHECKOUT ----------

    private void showCheckout() {
        if (currentCart == null || currentCart.items.isEmpty()) { showCart(); return; }
        setShell("checkout", "Оформление заказа", true, true, "cart");
        bottomNav.setVisibility(View.GONE);
        ScrollView scroll = pageScroll();
        LinearLayout body = pageBody(scroll);
        body.setPadding(dp(14), dp(16), dp(14), dp(30));

        body.addView(sectionTitle("Контактные данные"));
        EditText first = input("Имя *"); first.setText(prefs.getString(PREF_FIRST, "")); body.addView(first, margin(matchWrap(), 0, 8, 0, 0));
        EditText last = input("Фамилия *"); last.setText(prefs.getString(PREF_LAST, "")); body.addView(last, margin(matchWrap(), 0, 8, 0, 0));
        EditText phone = input("Телефон *"); phone.setInputType(InputType.TYPE_CLASS_PHONE); phone.setText(prefs.getString(PREF_PHONE, "")); body.addView(phone, margin(matchWrap(), 0, 8, 0, 0));
        EditText email = input("Email *"); email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS); email.setText(prefs.getString(PREF_EMAIL, "")); body.addView(email, margin(matchWrap(), 0, 8, 0, 0));

        body.addView(sectionTitle("Доставка"), margin(matchWrap(), 0, 22, 0, 0));
        EditText city = input("Город *"); city.setText(prefs.getString(PREF_CITY, "")); body.addView(city, margin(matchWrap(), 0, 8, 0, 0));
        EditText region = input("Область / край / республика *");
        region.setText(prefs.getString(PREF_REGION, defaultRegionForCity(city.getText().toString())));
        body.addView(region, margin(matchWrap(), 0, 8, 0, 0));
        EditText address = input("Улица, дом, квартира *"); address.setText(prefs.getString(PREF_ADDRESS, "")); body.addView(address, margin(matchWrap(), 0, 8, 0, 0));
        EditText postcode = input("Почтовый индекс * (6 цифр)");
        postcode.setInputType(InputType.TYPE_CLASS_NUMBER);
        postcode.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        postcode.setText(prefs.getString(PREF_POSTCODE, ""));
        body.addView(postcode, margin(matchWrap(), 0, 4, 0, 0));
        TextView postcodeHint = text("Индекс обязателен для оформления онлайн-оплаты через ЮKassa и сохраняется в профиле.", 11, MUTED, false);
        body.addView(postcodeHint, margin(matchWrap(), dp(6), 0, dp(6), 0));

        Button calculate = secondaryButton("Рассчитать доставку и оплату");
        body.addView(calculate, margin(matchWrap(), 0, 12, 0, 0));

        LinearLayout dynamic = new LinearLayout(this);
        dynamic.setOrientation(LinearLayout.VERTICAL);
        body.addView(dynamic, matchWrap());

        body.addView(sectionTitle("Комментарий"), margin(matchWrap(), 0, 22, 0, 0));
        EditText note = input("Комментарий к заказу");
        note.setSingleLine(false);
        note.setMinLines(3);
        note.setGravity(Gravity.TOP);
        body.addView(note, matchWrap());

        CheckBox terms = new CheckBox(this);
        terms.setText("Я принимаю пользовательское соглашение, политику конфиденциальности и согласен на обработку персональных данных.");
        terms.setTextColor(Color.rgb(55, 63, 59));
        terms.setTextSize(12);
        body.addView(terms, margin(matchWrap(), 0, 12, 0, 0));

        Button place = primaryButton("Оформить заказ");
        place.setEnabled(false);
        body.addView(place, margin(matchWrap(), 0, 14, 0, 0));
        TextView legal = text("Оплата будет обработана способом, доступным в магазине. Если платёжный сервис требует подтверждение, приложение откроет защищённую страницу сервиса оплаты.", 11, MUTED, false);
        body.addView(legal, margin(matchWrap(), 0, 10, 0, 0));

        replaceContent(scroll);

        final StoreModels.Cart[] calculated = {currentCart};
        final String[] paymentMethod = {""};
        final StoreModels.ShippingRate[] selectedRate = {null};

        Runnable calculateAction = () -> {
            if (!validateCheckout(first, last, phone, email, city, region, address, postcode)) return;
            saveProfile(first, last, phone, email, city, region, address, postcode);
            calculate.setEnabled(false);
            calculate.setText("Считаем…");
            dynamic.removeAllViews();
            dynamic.addView(loadingBlock("Получаем способы доставки…"));
            JSONObject billing = makeBilling(first, last, phone, email, city, region, address, postcode);
            JSONObject shipping = makeShipping(first, last, city, region, address, postcode);
            api.updateCustomer(billing, shipping, new StoreApiClient.Callback<StoreModels.Cart>() {
                @Override public void onSuccess(StoreModels.Cart cart) {
                    currentCart = cart;
                    calculated[0] = cart;
                    updateCartBadge(cart.itemsCount);
                    calculate.setEnabled(true);
                    calculate.setText("Пересчитать доставку и оплату");
                    renderCheckoutOptions(dynamic, cart, calculated, paymentMethod, selectedRate, place);
                }
                @Override public void onError(String message) {
                    calculate.setEnabled(true);
                    calculate.setText("Рассчитать доставку и оплату");
                    dynamic.removeAllViews();
                    dynamic.addView(errorBlock(message, v -> calculate.performClick()));
                }
            });
        };
        calculate.setOnClickListener(v -> calculateAction.run());

        place.setOnClickListener(v -> {
            if (!terms.isChecked()) { showToast("Подтвердите согласие с условиями оформления заказа."); return; }
            if (!validateCheckout(first, last, phone, email, city, region, address, postcode)) return;
            if (paymentMethod[0].isEmpty()) { showToast("Выберите способ оплаты."); return; }
            place.setEnabled(false);
            place.setText("Оформляем…");
            showPaymentOverlay("Создаём заказ", "Передаём заказ в магазин и готовим безопасную оплату. Обычно это занимает несколько секунд.");
            saveProfile(first, last, phone, email, city, region, address, postcode);
            JSONObject billing = makeBilling(first, last, phone, email, city, region, address, postcode);
            JSONObject shipping = makeShipping(first, last, city, region, address, postcode);
            String personalized = personalizationNote(calculated[0]);
            String customerNote = note.getText().toString().trim();
            if (!personalized.isEmpty()) customerNote = (customerNote.isEmpty() ? "" : customerNote + "\n\n") + personalized;
            String expected = calculated[0] == null ? "" : calculated[0].totalPriceRaw;
            api.checkout(billing, shipping, paymentMethod[0], customerNote, expected, new StoreApiClient.Callback<StoreModels.CheckoutResult>() {
                @Override public void onSuccess(StoreModels.CheckoutResult result) {
                    updatePaymentOverlay("Заказ создан", result.redirectUrl != null && !result.redirectUrl.isEmpty()
                            ? "Открываем защищённую страницу ЮKassa…"
                            : "Готово. Сохраняем заказ в приложении…");
                    saveOrder(result, calculated[0]);
                    clearPersonalizations(calculated[0]);
                    updateCartBadge(0);
                    showOrderSuccess(result);
                    if (result.redirectUrl != null && !result.redirectUrl.isEmpty()) {
                        try {
                            Intent payIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(result.redirectUrl));
                            payIntent.addCategory(Intent.CATEGORY_BROWSABLE);
                            startActivity(payIntent);
                        } catch (Exception e) {
                            showToast("Заказ создан, но страницу оплаты не удалось открыть. Откройте заказ в профиле.");
                        }
                    }
                }
                @Override public void onError(String message) {
                    hidePaymentOverlay();
                    place.setEnabled(true);
                    place.setText("Оформить заказ");
                    showToast(message);
                }
            });
        });
    }

    private void renderCheckoutOptions(LinearLayout dynamic, StoreModels.Cart cart, StoreModels.Cart[] calculated, String[] paymentMethod,
                                       StoreModels.ShippingRate[] selectedRate, Button place) {
        dynamic.removeAllViews();
        if (cart.needsShipping) {
            dynamic.addView(sectionTitle("Способ доставки"), margin(matchWrap(), 0, 8, 0, 0));
            if (cart.shippingRates.isEmpty()) {
                dynamic.addView(infoBlock("Для этого адреса магазин пока не вернул варианты доставки. Проверьте город и индекс."));
            } else {
                RadioGroup shippingGroup = new RadioGroup(this);
                shippingGroup.setOrientation(RadioGroup.VERTICAL);
                for (StoreModels.ShippingRate rate : cart.shippingRates) {
                    RadioButton radio = new RadioButton(this);
                    radio.setText(rate.name + ("0".equals(rate.priceRaw) ? " — бесплатно" : " — " + rate.priceText()));
                    radio.setTextSize(14);
                    radio.setTextColor(DEEP_GREEN);
                    radio.setId(View.generateViewId());
                    radio.setTag(rate);
                    radio.setChecked(rate.selected);
                    if (rate.selected) selectedRate[0] = rate;
                    shippingGroup.addView(radio, matchWrap());
                }
                shippingGroup.setOnCheckedChangeListener((group, checkedId) -> {
                    RadioButton selected = group.findViewById(checkedId);
                    if (selected == null || !(selected.getTag() instanceof StoreModels.ShippingRate)) return;
                    StoreModels.ShippingRate rate = (StoreModels.ShippingRate) selected.getTag();
                    selectedRate[0] = rate;
                    api.selectShippingRate(rate.packageId, rate.rateId, new StoreApiClient.Callback<StoreModels.Cart>() {
                        @Override public void onSuccess(StoreModels.Cart value) {
                            currentCart = value;
                            calculated[0] = value;
                            renderCheckoutOptions(dynamic, value, calculated, paymentMethod, selectedRate, place);
                        }
                        @Override public void onError(String message) { showToast(message); }
                    });
                });
                dynamic.addView(shippingGroup, margin(matchWrap(), 0, 6, 0, 0));
            }
        }

        dynamic.addView(sectionTitle("Способ оплаты"), margin(matchWrap(), 0, 16, 0, 0));
        if (cart.paymentMethods.isEmpty()) {
            dynamic.addView(infoBlock("Магазин не вернул доступные способы оплаты. Возможно, сначала нужно выбрать доставку."));
            place.setEnabled(false);
        } else {
            RadioGroup paymentGroup = new RadioGroup(this);
            paymentGroup.setOrientation(RadioGroup.VERTICAL);
            for (int i = 0; i < cart.paymentMethods.size(); i++) {
                String id = cart.paymentMethods.get(i);
                RadioButton radio = new RadioButton(this);
                radio.setText(paymentLabel(id));
                radio.setTextSize(14);
                radio.setTextColor(DEEP_GREEN);
                radio.setId(View.generateViewId());
                radio.setTag(id);
                if (i == 0) { radio.setChecked(true); paymentMethod[0] = id; }
                paymentGroup.addView(radio, matchWrap());
            }
            paymentGroup.setOnCheckedChangeListener((group, checkedId) -> {
                RadioButton selected = group.findViewById(checkedId);
                if (selected != null && selected.getTag() != null) paymentMethod[0] = String.valueOf(selected.getTag());
            });
            dynamic.addView(paymentGroup, margin(matchWrap(), 0, 4, 0, 0));
            place.setEnabled(true);
        }
        dynamic.addView(summaryRow("Итого", cart.totalText(), true), margin(matchWrap(), 0, 14, 0, 0));
    }

    private String paymentLabel(String id) {
        String v = id == null ? "" : id.toLowerCase(Locale.ROOT);
        if (v.equals("cod")) return "Оплата при получении";
        if (v.equals("bacs")) return "Банковский перевод";
        if (v.equals("cheque")) return "Оплата по счёту";
        if (v.contains("yookassa") || v.contains("yoo")) return "ЮKassa / онлайн-оплата";
        if (v.contains("tinkoff") || v.contains("tbank")) return "Т-Банк / онлайн-оплата";
        if (v.contains("paypal")) return "PayPal";
        return "Онлайн-оплата (" + id + ")";
    }

    private boolean validateCheckout(EditText first, EditText last, EditText phone, EditText email, EditText city, EditText region, EditText address, EditText postcode) {
        EditText[] fields = {first, last, phone, email, city, region, address, postcode};
        for (EditText field : fields) {
            if (field.getText().toString().trim().isEmpty()) {
                field.setError("Заполните поле");
                field.requestFocus();
                return false;
            }
        }
        if (!email.getText().toString().contains("@")) { email.setError("Проверьте email"); email.requestFocus(); return false; }
        String postcodeValue = postcode.getText().toString().trim();
        if (!postcodeValue.matches("\\d{6}")) {
            postcode.setError("Введите 6 цифр почтового индекса");
            postcode.requestFocus();
            showToast("Для ЮKassa нужен почтовый индекс из 6 цифр.");
            return false;
        }
        return true;
    }

    private JSONObject makeBilling(EditText first, EditText last, EditText phone, EditText email, EditText city, EditText region, EditText address, EditText postcode) {
        JSONObject o = new JSONObject();
        try {
            o.put("first_name", first.getText().toString().trim());
            o.put("last_name", last.getText().toString().trim());
            o.put("company", "");
            o.put("address_1", address.getText().toString().trim());
            o.put("address_2", "");
            o.put("city", city.getText().toString().trim());
            o.put("state", region.getText().toString().trim());
            o.put("postcode", postcode.getText().toString().trim());
            o.put("country", "RU");
            o.put("email", email.getText().toString().trim());
            o.put("phone", phone.getText().toString().trim());
        } catch (Exception ignored) {}
        return o;
    }

    private JSONObject makeShipping(EditText first, EditText last, EditText city, EditText region, EditText address, EditText postcode) {
        JSONObject o = new JSONObject();
        try {
            o.put("first_name", first.getText().toString().trim());
            o.put("last_name", last.getText().toString().trim());
            o.put("company", "");
            o.put("address_1", address.getText().toString().trim());
            o.put("address_2", "");
            o.put("city", city.getText().toString().trim());
            o.put("state", region.getText().toString().trim());
            o.put("postcode", postcode.getText().toString().trim());
            o.put("country", "RU");
        } catch (Exception ignored) {}
        return o;
    }

    private String personalizationNote(StoreModels.Cart cart) {
        if (cart == null) return "";
        StringBuilder sb = new StringBuilder();
        for (StoreModels.CartItem item : cart.items) {
            String child = item.childName;
            if (child.isEmpty()) child = prefs.getString(ROOF_PREFIX + item.id, "");
            if (!child.isEmpty()) {
                if (sb.length() == 0) sb.append("Персонализация «Лигрик»:\n");
                sb.append("• ").append(item.name).append(" — имя для подарочной крыши: ").append(child).append("\n");
            }
        }
        return sb.toString().trim();
    }

    private void showOrderSuccess(StoreModels.CheckoutResult result) {
        setShell("success", "Заказ создан", true, false, "cart");
        bottomNav.setVisibility(View.GONE);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(28), dp(48), dp(28), dp(28));
        body.setBackgroundColor(CREAM);
        body.addView(text("✓", 58, GREEN, true), margin(wrap(), 0, 0, 0, 0));
        TextView title = text("Заказ создан!", 28, DEEP_GREEN, true);
        title.setGravity(Gravity.CENTER);
        body.addView(title, margin(matchWrap(), 0, 14, 0, 0));
        String number = result.orderNumber == null || result.orderNumber.isEmpty() ? String.valueOf(result.orderId) : result.orderNumber;
        TextView desc = text("Заказ №" + number + " создан. Мы сохранили его в разделе «Профиль».", 15, MUTED, false);
        desc.setGravity(Gravity.CENTER);
        body.addView(desc, margin(matchWrap(), dp(10), 10, dp(10), 0));
        if (result.redirectUrl != null && !result.redirectUrl.isEmpty()) {
            TextView pay = text("Завершите оплату на защищённой странице ЮKassa. После возврата заказ останется в разделе «Профиль».", 13, MUTED, false);
            pay.setGravity(Gravity.CENTER);
            body.addView(pay, margin(matchWrap(), 0, 10, 0, 0));
        }
        Button home = primaryButton("На главную");
        home.setOnClickListener(v -> showHome());
        body.addView(home, margin(matchWrap(), 0, 24, 0, 0));
        Button profile = secondaryButton("Мои заказы");
        profile.setOnClickListener(v -> showProfile());
        body.addView(profile, margin(matchWrap(), 0, 10, 0, 0));
        replaceContent(body);
    }

    // ---------- PROFILE ----------

    private void showProfile() {
        currentProduct = null;
        setShell("profile", "Профиль", true, false, "profile");
        ScrollView scroll = pageScroll();
        LinearLayout body = pageBody(scroll);
        body.setPadding(dp(14), dp(18), dp(14), dp(28));
        body.addView(sectionTitle("Данные покупателя"));
        body.addView(text("Они сохраняются только на этом устройстве и подставляются при оформлении заказа.", 13, MUTED, false), margin(matchWrap(), 0, 6, 0, 0));
        EditText first = input("Имя"); first.setText(prefs.getString(PREF_FIRST, "")); body.addView(first, margin(matchWrap(), 0, 10, 0, 0));
        EditText last = input("Фамилия"); last.setText(prefs.getString(PREF_LAST, "")); body.addView(last, margin(matchWrap(), 0, 8, 0, 0));
        EditText phone = input("Телефон"); phone.setInputType(InputType.TYPE_CLASS_PHONE); phone.setText(prefs.getString(PREF_PHONE, "")); body.addView(phone, margin(matchWrap(), 0, 8, 0, 0));
        EditText email = input("Email"); email.setText(prefs.getString(PREF_EMAIL, "")); body.addView(email, margin(matchWrap(), 0, 8, 0, 0));
        EditText city = input("Город"); city.setText(prefs.getString(PREF_CITY, "")); body.addView(city, margin(matchWrap(), 0, 8, 0, 0));
        EditText region = input("Область / край / республика"); region.setText(prefs.getString(PREF_REGION, defaultRegionForCity(city.getText().toString()))); body.addView(region, margin(matchWrap(), 0, 8, 0, 0));
        EditText address = input("Адрес"); address.setText(prefs.getString(PREF_ADDRESS, "")); body.addView(address, margin(matchWrap(), 0, 8, 0, 0));
        EditText postcode = input("Почтовый индекс (6 цифр)");
        postcode.setInputType(InputType.TYPE_CLASS_NUMBER);
        postcode.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        postcode.setText(prefs.getString(PREF_POSTCODE, ""));
        body.addView(postcode, margin(matchWrap(), 0, 8, 0, 0));
        Button save = primaryButton("Сохранить данные");
        save.setOnClickListener(v -> { saveProfile(first, last, phone, email, city, region, address, postcode); showToast("Данные сохранены"); });
        body.addView(save, margin(matchWrap(), 0, 12, 0, 0));

        body.addView(sectionTitle("Заказы из приложения"), margin(matchWrap(), 0, 26, 0, 0));
        String raw = prefs.getString(PREF_RECENT_ORDERS, "[]");
        try {
            JSONArray orders = new JSONArray(raw);
            if (orders.length() == 0) body.addView(infoBlock("Здесь появятся заказы, оформленные в приложении «Лигрик»."));
            else {
                for (int i = 0; i < orders.length(); i++) {
                    JSONObject o = orders.optJSONObject(i);
                    if (o == null) continue;
                    LinearLayout card = new LinearLayout(this);
                    card.setOrientation(LinearLayout.VERTICAL);
                    card.setPadding(dp(14), dp(13), dp(14), dp(13));
                    card.setBackground(roundRect(Color.WHITE, dp(18), 0, 0));
                    card.addView(text("Заказ №" + o.optString("number", ""), 16, DEEP_GREEN, true));
                    card.addView(text(o.optString("date", "") + "  •  " + o.optString("total", ""), 12, MUTED, false), margin(matchWrap(), 0, 5, 0, 0));
                    String status = o.optString("status", "");
                    if (!status.isEmpty()) card.addView(text("Статус: " + status, 12, GREEN, true), margin(matchWrap(), 0, 5, 0, 0));
                    body.addView(card, margin(matchWrap(), 0, 9, 0, 0));
                }
            }
        } catch (Exception e) { body.addView(infoBlock("История заказов пока недоступна.")); }
        replaceContent(scroll);
    }

    private void saveProfile(EditText first, EditText last, EditText phone, EditText email, EditText city, EditText region, EditText address, EditText postcode) {
        prefs.edit()
                .putString(PREF_FIRST, first.getText().toString().trim())
                .putString(PREF_LAST, last.getText().toString().trim())
                .putString(PREF_PHONE, phone.getText().toString().trim())
                .putString(PREF_EMAIL, email.getText().toString().trim())
                .putString(PREF_CITY, city.getText().toString().trim())
                .putString(PREF_REGION, region.getText().toString().trim())
                .putString(PREF_ADDRESS, address.getText().toString().trim())
                .putString(PREF_POSTCODE, postcode.getText().toString().trim())
                .apply();
    }

    private String defaultRegionForCity(String city) {
        String c = city == null ? "" : city.trim().toLowerCase(new Locale("ru", "RU"));
        if (c.contains("новосибир")) return "Новосибирская область";
        if (c.equals("москва")) return "Москва";
        if (c.contains("санкт-петербург") || c.equals("петербург") || c.equals("спб")) return "Санкт-Петербург";
        if (c.contains("севастопол")) return "Севастополь";
        return "";
    }

    private void saveOrder(StoreModels.CheckoutResult result, StoreModels.Cart cart) {
        try {
            JSONArray old = new JSONArray(prefs.getString(PREF_RECENT_ORDERS, "[]"));
            JSONArray newer = new JSONArray();
            JSONObject row = new JSONObject();
            String number = result.orderNumber == null || result.orderNumber.isEmpty() ? String.valueOf(result.orderId) : result.orderNumber;
            row.put("number", number);
            row.put("status", result.status);
            row.put("date", new SimpleDateFormat("dd.MM.yyyy HH:mm", new Locale("ru", "RU")).format(new Date()));
            row.put("total", cart == null ? "" : cart.totalText());
            row.put("order_id", result.orderId);
            row.put("order_key", result.orderKey);
            newer.put(row);
            for (int i = 0; i < Math.min(old.length(), 9); i++) newer.put(old.get(i));
            prefs.edit().putString(PREF_RECENT_ORDERS, newer.toString()).apply();
        } catch (Exception ignored) {}
    }

    // ---------- STATE ----------

    private Set<String> favoriteSet() { return new HashSet<>(prefs.getStringSet(PREF_FAVORITES, new HashSet<>())); }
    private boolean isFavorite(int id) { return favoriteSet().contains(String.valueOf(id)); }
    private void toggleFavorite(int id) {
        Set<String> set = favoriteSet();
        String key = String.valueOf(id);
        if (set.contains(key)) { set.remove(key); showToast("Удалено из избранного"); }
        else { set.add(key); showToast("Добавлено в избранное"); }
        prefs.edit().putStringSet(PREF_FAVORITES, set).apply();
    }
    private List<Integer> favoriteIds() {
        List<Integer> ids = new ArrayList<>();
        for (String s : favoriteSet()) try { ids.add(Integer.parseInt(s)); } catch (Exception ignored) {}
        return ids;
    }

    private void clearPersonalizations(StoreModels.Cart cart) {
        if (cart == null) return;
        SharedPreferences.Editor e = prefs.edit();
        for (StoreModels.CartItem item : cart.items) e.remove(ROOF_PREFIX + item.id);
        e.apply();
    }

    private void refreshCartBadge() {
        api.getCart(new StoreApiClient.Callback<StoreModels.Cart>() {
            @Override public void onSuccess(StoreModels.Cart cart) { currentCart = cart; updateCartBadge(cart.itemsCount); }
            @Override public void onError(String message) { updateCartBadge(0); }
        });
    }

    private void updateCartBadge(int count) {
        if (cartBadge == null) return;
        if (count <= 0) cartBadge.setVisibility(View.GONE);
        else {
            cartBadge.setText(count > 99 ? "99+" : String.valueOf(count));
            cartBadge.setVisibility(View.VISIBLE);
        }
    }

    // ---------- BACK ----------

    private void goBack() {
        if ("product".equals(screen)) showCatalog();
        else if ("checkout".equals(screen)) showCart();
        else if ("success".equals(screen)) showHome();
        else if (!"home".equals(screen)) showHome();
        else finish();
    }

    @Override
    public void onBackPressed() { goBack(); }

    // ---------- UI HELPERS ----------

    private ScrollView pageScroll() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(CREAM);
        return scroll;
    }

    private LinearLayout pageBody(ScrollView scroll) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setBackgroundColor(CREAM);
        scroll.addView(body, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return body;
    }

    private TextView sectionTitle(String value) { return text(value, 24, DEEP_GREEN, true); }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setLineSpacing(dp(2), 1f);
        return t;
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(145, 151, 147));
        e.setTextColor(Color.rgb(35, 42, 38));
        e.setTextSize(15);
        e.setPadding(dp(14), 0, dp(14), 0);
        e.setBackground(roundRect(Color.WHITE, dp(14), BORDER, dp(1)));
        e.setMinHeight(dp(52));
        return e;
    }

    private Button primaryButton(String label) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundRect(GREEN, dp(26), 0, 0));
        b.setMinHeight(dp(56));
        return b;
    }

    private Button secondaryButton(String label) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextColor(GREEN);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(roundRect(Color.WHITE, dp(26), GREEN, dp(1)));
        b.setMinHeight(dp(54));
        return b;
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(6), 0, dp(6), 0);
        b.setBackground(roundRect(GREEN, dp(14), 0, 0));
        return b;
    }

    private Button tinyButton(String label) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(18);
        b.setTextColor(DEEP_GREEN);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(roundRect(SOFT_GREEN, dp(12), 0, 0));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        return b;
    }

    private View summaryRow(String left, String right, boolean big) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(text(left, big ? 20 : 14, DEEP_GREEN, big), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView price = text(right, big ? 22 : 14, big ? GREEN : DEEP_GREEN, big);
        price.setGravity(Gravity.RIGHT);
        row.addView(price, wrap());
        return row;
    }

    private void showPaymentOverlay(String title, String message) {
        hidePaymentOverlay();
        FrameLayout overlay = new FrameLayout(this);
        overlay.setClickable(true);
        overlay.setFocusable(true);
        overlay.setBackgroundColor(Color.argb(155, 20, 28, 24));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(26), dp(24), dp(26), dp(24));
        card.setBackground(roundRect(PAPER, dp(24), 0, 0));
        card.setTag("payment_card");

        ProgressBar spinner = new ProgressBar(this);
        card.addView(spinner, new LinearLayout.LayoutParams(dp(46), dp(46)));
        TextView h = text(title, 20, DEEP_GREEN, true);
        h.setGravity(Gravity.CENTER);
        h.setTag("payment_title");
        card.addView(h, margin(matchWrap(), 0, 16, 0, 0));
        TextView m = text(message, 13, MUTED, false);
        m.setGravity(Gravity.CENTER);
        m.setTag("payment_message");
        card.addView(m, margin(matchWrap(), 0, 8, 0, 0));

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        cp.setMargins(dp(28), 0, dp(28), 0);
        overlay.addView(card, cp);
        content.addView(overlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        paymentOverlay = overlay;
    }

    private void updatePaymentOverlay(String title, String message) {
        if (paymentOverlay == null) return;
        View h = paymentOverlay.findViewWithTag("payment_title");
        View m = paymentOverlay.findViewWithTag("payment_message");
        if (h instanceof TextView) ((TextView) h).setText(title);
        if (m instanceof TextView) ((TextView) m).setText(message);
    }

    private void hidePaymentOverlay() {
        if (paymentOverlay != null) {
            ViewGroup parent = (ViewGroup) paymentOverlay.getParent();
            if (parent != null) parent.removeView(paymentOverlay);
            paymentOverlay = null;
        }
    }

    private void handlePaymentReturnIntent(Intent intent) {
        if (intent == null || intent.getData() == null) return;
        Uri uri = intent.getData();
        if (!"ligrik".equalsIgnoreCase(uri.getScheme()) || !"payment-return".equalsIgnoreCase(uri.getHost())) return;
        showProfile();
        showToast("Вы вернулись из ЮKassa. Заказ сохранён в разделе «Профиль». ");
    }

    private View loadingBlock(String message) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setGravity(Gravity.CENTER);
        block.setPadding(dp(18), dp(36), dp(18), dp(36));
        ProgressBar p = new ProgressBar(this, null, android.R.attr.progressBarStyleSmall);
        block.addView(p, new LinearLayout.LayoutParams(dp(30), dp(30)));
        TextView t = text(message, 13, MUTED, false);
        t.setGravity(Gravity.CENTER);
        block.addView(t, margin(wrap(), 0, 10, 0, 0));
        return block;
    }

    private View infoBlock(String message) {
        TextView t = text(message, 13, MUTED, false);
        t.setPadding(dp(15), dp(14), dp(15), dp(14));
        t.setBackground(roundRect(SOFT_GREEN, dp(16), 0, 0));
        return t;
    }

    private View emptyBlock(String title, String message) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setGravity(Gravity.CENTER_HORIZONTAL);
        block.setPadding(dp(20), dp(50), dp(20), dp(30));
        TextView icon = text("♡", 48, GREEN, false);
        block.addView(icon, wrap());
        TextView h = text(title, 23, DEEP_GREEN, true); h.setGravity(Gravity.CENTER); block.addView(h, margin(matchWrap(), 0, 10, 0, 0));
        TextView m = text(message, 14, MUTED, false); m.setGravity(Gravity.CENTER); block.addView(m, margin(matchWrap(), dp(10), 8, dp(10), 0));
        return block;
    }

    private View errorBlock(String message, View.OnClickListener retry) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setGravity(Gravity.CENTER_HORIZONTAL);
        block.setPadding(dp(18), dp(28), dp(18), dp(28));
        TextView h = text("Не удалось загрузить", 19, DEEP_GREEN, true); h.setGravity(Gravity.CENTER); block.addView(h);
        TextView m = text(message, 13, MUTED, false); m.setGravity(Gravity.CENTER); block.addView(m, margin(matchWrap(), 0, 8, 0, 0));
        Button b = secondaryButton("Повторить"); b.setOnClickListener(retry); block.addView(b, margin(new LinearLayout.LayoutParams(dp(180), dp(52)), 0, 14, 0, 0));
        return block;
    }

    private GradientDrawable roundRect(int color, float radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, strokeColor);
        return d;
    }

    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams wrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams margin(LinearLayout.LayoutParams p, int left, int top, int right, int bottom) { p.setMargins(left, top, right, bottom); return p; }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private String join(List<String> values, String separator) {
        StringBuilder sb = new StringBuilder();
        for (String v : values) { if (v == null || v.isEmpty()) continue; if (sb.length() > 0) sb.append(separator); sb.append(v); }
        return sb.toString();
    }

    private String pluralProducts(int count) {
        int n = Math.abs(count) % 100;
        int n1 = n % 10;
        if (n > 10 && n < 20) return "товаров";
        if (n1 > 1 && n1 < 5) return "товара";
        if (n1 == 1) return "товар";
        return "товаров";
    }

    private void showToast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    private static final class NavItem {
        final String target;
        final LinearLayout root;
        final ImageView icon;
        final TextView label;
        NavItem(String target, LinearLayout root, ImageView icon, TextView label) { this.target = target; this.root = root; this.icon = icon; this.label = label; }
    }
}
