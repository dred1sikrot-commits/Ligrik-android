<?php
/**
 * Plugin Name: LIGRIK Native Bridge
 * Description: Интеграция нативного приложения LIGRIK с WooCommerce Store API: необязательная именная крыша, корзина и сохранение имени в заказе.
 * Version: 1.1.0
 * Author: LIGRIK
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Определяем запрос именно от нативного приложения.
 * Приложение передаёт ligrik_native_app=1 при POST /wc/store/v1/cart/add-item.
 */
function ligrik_native_is_app_request() {
    if ( isset( $_REQUEST['ligrik_native_app'] ) && '1' === (string) $_REQUEST['ligrik_native_app'] ) {
        return true;
    }

    if ( isset( $_GET['ligrik_native_app'] ) && '1' === (string) $_GET['ligrik_native_app'] ) {
        return true;
    }

    $ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
    return false !== stripos( $ua, 'LIGRIK-Native-Android/' );
}

function ligrik_native_clean_child_name( $value ) {
    $name = sanitize_text_field( (string) $value );
    if ( function_exists( 'mb_substr' ) ) {
        return mb_substr( $name, 0, 18 );
    }
    return substr( $name, 0, 18 );
}

/**
 * Передаём имя в cart_item_data. Пустое имя — абсолютно допустимо:
 * именная крыша является подарочной опцией по желанию покупателя.
 */
add_filter( 'woocommerce_store_api_add_to_cart_data', function( $add_to_cart_data, $request ) {
    if ( ! ligrik_native_is_app_request() ) {
        return $add_to_cart_data;
    }

    $name = ligrik_native_clean_child_name( $request->get_param( 'ligrik_child_name' ) );
    if ( '' !== $name ) {
        $add_to_cart_data['cart_item_data']['ligrik_child_name'] = $name;
    }

    return $add_to_cart_data;
}, 10, 2 );

/**
 * На сайте ранее могла быть установлена серверная проверка, которая делала поле
 * имени обязательным. Для нативного приложения снимаем ТОЛЬКО такую ошибку.
 * Любые ошибки наличия, вариаций, количества и прочие проверки WooCommerce
 * остаются нетронутыми.
 */
add_filter( 'woocommerce_add_to_cart_validation', function( $passed, $product_id, $quantity, $variation_id = 0, $variations = array(), $cart_item_data = array() ) {
    if ( $passed || ! ligrik_native_is_app_request() || ! function_exists( 'wc_get_notices' ) ) {
        return $passed;
    }

    $errors = wc_get_notices( 'error' );
    if ( empty( $errors ) || ! is_array( $errors ) ) {
        return $passed;
    }

    $name_errors = array();
    $other_errors = array();

    foreach ( $errors as $notice ) {
        $message = is_array( $notice ) && isset( $notice['notice'] ) ? (string) $notice['notice'] : (string) $notice;
        $plain   = wp_strip_all_tags( $message );
        $lower   = function_exists( 'mb_strtolower' ) ? mb_strtolower( $plain, 'UTF-8' ) : strtolower( $plain );

        $mentions_name = false !== strpos( $lower, 'имя' );
        $mentions_roof = false !== strpos( $lower, 'крыш' ) || false !== strpos( $lower, 'подароч' );

        if ( $mentions_name && $mentions_roof ) {
            $name_errors[] = $notice;
        } else {
            $other_errors[] = $notice;
        }
    }

    // Снимаем запрет только когда единственная причина отказа — обязательное имя.
    if ( ! empty( $name_errors ) && empty( $other_errors ) ) {
        wc_clear_notices();
        return true;
    }

    return $passed;
}, PHP_INT_MAX, 6 );

/** Показываем имя в Store API item_data и в обычной корзине WooCommerce. */
add_filter( 'woocommerce_get_item_data', function( $item_data, $cart_item ) {
    if ( ! empty( $cart_item['ligrik_child_name'] ) ) {
        $item_data[] = array(
            'key'   => 'Имя для подарочной крыши',
            'value' => sanitize_text_field( $cart_item['ligrik_child_name'] ),
        );
    }
    return $item_data;
}, 10, 2 );

/** Сохраняем имя в строке заказа только если покупатель его действительно указал. */
add_action( 'woocommerce_checkout_create_order_line_item', function( $item, $cart_item_key, $values, $order ) {
    if ( ! empty( $values['ligrik_child_name'] ) ) {
        $item->add_meta_data( 'Имя для подарочной крыши', sanitize_text_field( $values['ligrik_child_name'] ), true );
    }
}, 10, 4 );
