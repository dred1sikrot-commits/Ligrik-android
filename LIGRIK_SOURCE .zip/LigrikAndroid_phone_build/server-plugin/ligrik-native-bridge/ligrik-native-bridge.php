<?php
/**
 * Plugin Name: LIGRIK Native Bridge
 * Description: Интеграция нативного приложения LIGRIK с WooCommerce Store API: необязательная именная крыша, корзина и сохранение имени в заказе.
 * Version: 1.2.0
 * Author: LIGRIK
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Определяем запрос именно от нативного приложения.
 * Приложение передаёт ligrik_native_app=1 при POST /wc/store/v1/cart/add-item.
 */
function ligrik_native_is_app_request() {
    if ( isset( $_REQUEST['ligrik_native_app'] ) && '1' === (string) $_REQUEST['ligrik_native_app'] ) {
        return true;
    }

    if ( isset( $_GET['ligrik_native_app'] ) && '1' === (string) $_GET['ligrik_native_app'] ) {
        return true;
    }

    $ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
    return false !== stripos( $ua, 'LIGRIK-Native-Android/' );
}

function ligrik_native_clean_child_name( $value ) {
    $name = sanitize_text_field( (string) $value );
    if ( function_exists( 'mb_substr' ) ) {
        return mb_substr( $name, 0, 18 );
    }
    return substr( $name, 0, 18 );
}

/**
 * Передаём имя в cart_item_data. Пустое имя — абсолютно допустимо:
 * именная крыша является подарочной опцией по желанию покупателя.
 */
add_filter( 'woocommerce_store_api_add_to_cart_data', function( $add_to_cart_data, $request ) {
    if ( ! ligrik_native_is_app_request() ) {
        return $add_to_cart_data;
    }

    $name = ligrik_native_clean_child_name( $request->get_param( 'ligrik_child_name' ) );
    if ( '' !== $name ) {
        $add_to_cart_data['cart_item_data']['ligrik_child_name'] = $name;
    }

    return $add_to_cart_data;
}, 10, 2 );

/**
 * На сайте ранее могла быть установлена серверная проверка, которая делала поле
 * имени обязательным. Для нативного приложения снимаем ТОЛЬКО такую ошибку.
 * Любые ошибки наличия, вариаций, количества и прочие проверки WooCommerce
 * остаются нетронутыми.
 */
add_filter( 'woocommerce_add_to_cart_validation', function( $passed, $product_id, $quantity, $variation_id = 0, $variations = array(), $cart_item_data = array() ) {
    if ( $passed || ! ligrik_native_is_app_request() || ! function_exists( 'wc_get_notices' ) ) {
        return $passed;
    }

    $errors = wc_get_notices( 'error' );
    if ( empty( $errors ) || ! is_array( $errors ) ) {
        return $passed;
    }

    $name_errors = array();
    $other_errors = array();

    foreach ( $errors as $notice ) {
        $message = is_array( $notice ) && isset( $notice['notice'] ) ? (string) $notice['notice'] : (string) $notice;
        $plain   = wp_strip_all_tags( $message );
        $lower   = function_exists( 'mb_strtolower' ) ? mb_strtolower( $plain, 'UTF-8' ) : strtolower( $plain );

        $mentions_name = false !== strpos( $lower, 'имя' );
        $mentions_roof = false !== strpos( $lower, 'крыш' ) || false !== strpos( $lower, 'подароч' );

        if ( $mentions_name && $mentions_roof ) {
            $name_errors[] = $notice;
        } else {
            $other_errors[] = $notice;
        }
    }

    // Снимаем запрет только когда единственная причина отказа — обязательное имя.
    if ( ! empty( $name_errors ) && empty( $other_errors ) ) {
        wc_clear_notices();
        return true;
    }

    return $passed;
}, PHP_INT_MAX, 6 );

/** Показываем имя в Store API item_data и в обычной корзине WooCommerce. */
add_filter( 'woocommerce_get_item_data', function( $item_data, $cart_item ) {
    if ( ! empty( $cart_item['ligrik_child_name'] ) ) {
        $item_data[] = array(
            'key'   => 'Имя для подарочной крыши',
            'value' => sanitize_text_field( $cart_item['ligrik_child_name'] ),
        );
    }
    return $item_data;
}, 10, 2 );

/** Сохраняем имя в строке заказа только если покупатель его действительно указал. */
add_action( 'woocommerce_checkout_create_order_line_item', function( $item, $cart_item_key, $values, $order ) {
    if ( ! empty( $values['ligrik_child_name'] ) ) {
        $item->add_meta_data( 'Имя для подарочной крыши', sanitize_text_field( $values['ligrik_child_name'] ), true );
    }
}, 10, 4 );


/**
 * Для заказов из приложения не допускаем возврат ЮKassa в /wp-admin.
 * Возвращаем на специальную публичную страницу LIGRIK, которая затем
 * предлагает/пытается открыть приложение через ligrik://payment-return.
 */
add_filter( 'woocommerce_get_return_url', function( $return_url, $order ) {
    if ( ! ligrik_native_is_app_request() ) {
        return $return_url;
    }

    $args = array( 'ligrik_app_payment_return' => '1' );
    if ( $order instanceof WC_Order ) {
        $args['order_id'] = $order->get_id();
        $args['key']      = $order->get_order_key();
    }

    return add_query_arg( $args, home_url( '/' ) );
}, 999, 2 );

/** Публичная страница возврата после ЮKassa для нативного приложения. */
add_action( 'template_redirect', function() {
    if ( empty( $_GET['ligrik_app_payment_return'] ) ) {
        return;
    }

    $order_id = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
    $key      = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
    $deep     = 'ligrik://payment-return';
    if ( $order_id ) {
        $deep = add_query_arg( array( 'order_id' => $order_id, 'key' => $key ), $deep );
    }

    status_header( 200 );
    nocache_headers();
    header( 'Content-Type: text/html; charset=utf-8' );
    ?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>LIGRIK — возврат из оплаты</title>
<style>
body{margin:0;background:#f8f3ea;color:#17392b;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;box-sizing:border-box}
.card{max-width:520px;background:#fffdf9;border-radius:28px;padding:34px 26px;text-align:center;box-shadow:0 12px 36px rgba(23,57,43,.12)}
h1{font-size:30px;margin:10px 0 14px}.ok{font-size:56px}.muted{color:#68756d;font-size:17px;line-height:1.45}.btn{display:block;margin-top:24px;padding:17px 22px;background:#1f4d3a;color:#fff;text-decoration:none;border-radius:22px;font-weight:700;font-size:18px}
</style>
</head>
<body>
<div class="card">
<div class="ok">✓</div>
<h1>Возвращаемся в LIGRIK</h1>
<p class="muted">Платёжная страница завершила работу. Откройте приложение, чтобы посмотреть заказ.</p>
<a class="btn" href="<?php echo esc_attr( $deep ); ?>">Открыть приложение LIGRIK</a>
</div>
<script>setTimeout(function(){window.location.href=<?php echo wp_json_encode( $deep ); ?>;},700);</script>
</body>
</html>
    <?php
    exit;
}, 0 );
