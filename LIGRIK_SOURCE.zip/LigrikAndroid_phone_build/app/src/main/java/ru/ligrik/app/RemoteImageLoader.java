package ru.ligrik.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class RemoteImageLoader {
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(2);

    private RemoteImageLoader() {}

    public static void load(Activity activity, ImageView imageView, String url) {
        EXECUTOR.execute(() -> {
            Bitmap bitmap = null;
            try {
                File cacheDir = new File(activity.getCacheDir(), "brand_images");
                if (!cacheDir.exists()) cacheDir.mkdirs();
                File cached = new File(cacheDir, sha1(url) + ".img");

                if (cached.exists() && cached.length() > 0) {
                    try (InputStream in = new FileInputStream(cached)) {
                        bitmap = BitmapFactory.decodeStream(in);
                    }
                }

                if (bitmap == null) {
                    HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(7000);
                    connection.setInstanceFollowRedirects(true);
                    connection.setRequestProperty("User-Agent", "LigrikAndroidApp/3.0");
                    connection.connect();
                    if (connection.getResponseCode() >= 200 && connection.getResponseCode() < 300) {
                        try (InputStream in = connection.getInputStream()) {
                            byte[] bytes = readAll(in);
                            bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                            if (bitmap != null) {
                                try (FileOutputStream out = new FileOutputStream(cached)) {
                                    out.write(bytes);
                                }
                            }
                        }
                    }
                    connection.disconnect();
                }
            } catch (Exception ignored) {
                // Splash remains usable even if the network image cannot be loaded.
            }

            Bitmap result = bitmap;
            if (result != null && !activity.isFinishing()) {
                activity.runOnUiThread(() -> imageView.setImageBitmap(result));
            }
        });
    }

    private static byte[] readAll(InputStream inputStream) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int count;
        while ((count = inputStream.read(buffer)) != -1) {
            output.write(buffer, 0, count);
        }
        return output.toByteArray();
    }

    private static String sha1(String value) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-1");
        byte[] bytes = digest.digest(value.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
