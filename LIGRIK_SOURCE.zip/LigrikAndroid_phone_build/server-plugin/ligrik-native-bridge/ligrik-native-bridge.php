<?php
/**
 * Plugin Name: LIGRIK Native Bridge
 * Description: Передаёт имя для подарочной крыши из нативного приложения LIGRIK в корзину и заказ WooCommerce Store API.
 * Version: 1.0.0
 * Author: LIGRIK
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Store API позволяет читать дополнительные request-параметры через этот filter.
 * Имя становится частью cart_item_data, поэтому товары с разными именами не склеиваются.
 */
add_filter( 'woocommerce_store_api_add_to_cart_data', function( $add_to_cart_data, $request ) {
    $name = sanitize_text_field( (string) $request->get_param( 'ligrik_child_name' ) );
    if ( $name !== '' ) {
        $name = mb_substr( $name, 0, 18 );
        $add_to_cart_data['cart_item_data']['ligrik_child_name'] = $name;
    }
    return $add_to_cart_data;
}, 10, 2 );

/** Показываем имя в item_data Store API и в обычной корзине WooCommerce. */
add_filter( 'woocommerce_get_item_data', function( $item_data, $cart_item ) {
    if ( ! empty( $cart_item['ligrik_child_name'] ) ) {
        $item_data[] = array(
            'key'   => 'Имя для подарочной крыши',
            'value' => sanitize_text_field( $cart_item['ligrik_child_name'] ),
        );
    }
    return $item_data;
}, 10, 2 );

/** Сохраняем имя в строке заказа. */
add_action( 'woocommerce_checkout_create_order_line_item', function( $item, $cart_item_key, $values, $order ) {
    if ( ! empty( $values['ligrik_child_name'] ) ) {
        $item->add_meta_data( 'Имя для подарочной крыши', sanitize_text_field( $values['ligrik_child_name'] ), true );
    }
}, 10, 4 );
