package ru.ligrik.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int GREEN = Color.rgb(31, 77, 58);
    private static final int DEEP_GREEN = Color.rgb(25, 51, 40);
    private static final int CREAM = Color.rgb(246, 240, 230);
    private static final int SOFT_GREEN = Color.rgb(232, 239, 234);
    private static final int MUTED = Color.rgb(87, 103, 94);

    private static final String HOME_URL = "native://home";
    private static final String CATALOG_URL = "https://ligrik.ru/catalog/";
    private static final String CART_URL = "https://ligrik.ru/cart/";
    private static final String ACCOUNT_URL = "https://ligrik.ru/my-account/";

    private static final String CAT_SMALL = "https://ligrik.ru/product-category/malenkie-bizidomiki/";
    private static final String CAT_MEDIUM = "https://ligrik.ru/product-category/srednie-bizidomiki/";
    private static final String CAT_LARGE = "https://ligrik.ru/product-category/bolshie-bizidomiki/";
    private static final String CAT_HUGE = "https://ligrik.ru/product-category/ogromnye-bizidomiki/";

    private static final String IMG_SMALL = "https://ligrik.ru/wp-content/uploads/2026/07/malenkie-bizidomiki-1.webp";
    private static final String IMG_MEDIUM = "https://ligrik.ru/wp-content/uploads/2026/07/srednie-bizidomiki.webp";
    private static final String IMG_LARGE = "https://ligrik.ru/wp-content/uploads/2026/07/bolshie-bizidomiki.webp";
    private static final String IMG_HUGE = "https://ligrik.ru/wp-content/uploads/2026/07/ogromnye-bizidomiki.webp";
    private static final String LOGO_URL = "https://ligrik.ru/wp-content/uploads/2026/07/ligrik-logo-kubiki.webp";
    private static final String MASCOT_URL = "https://ligrik.ru/wp-content/uploads/2026/07/ligrik-otdelno-ot-logo.webp";

    private static final int FILE_CHOOSER_REQUEST = 6001;

    private WebView webView;
    private ScrollView homeView;
    private ProgressBar progressBar;
    private ValueCallback<Uri[]> filePathCallback;
    private TextView toolbarTitle;
    private ImageButton backButton;
    private ImageButton refreshButton;
    private LinearLayout toolbar;
    private FrameLayout contentFrame;
    private LinearLayout errorView;
    private boolean showingHome = true;
    private final List<NavItem> navItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(GREEN);
        getWindow().setNavigationBarColor(CREAM);

        buildUi();
        configureWebView();
        showNativeHome();

        // Warm up the store in the background so the first transition feels faster.
        webView.loadUrl(CATALOG_URL);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        // Android 15 (targetSdk 35) draws apps edge-to-edge by default.
        // Keep a dedicated safe-area strip under the system status bar so
        // the app toolbar/back button never sits underneath the clock/icons.
        View statusBarSpacer = new View(this);
        statusBarSpacer.setBackgroundColor(GREEN);
        root.addView(statusBarSpacer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0
        ));

        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(6), 0, dp(6), 0);
        toolbar.setBackgroundColor(GREEN);
        root.addView(toolbar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)
        ));

        backButton = new ImageButton(this);
        backButton.setImageResource(R.drawable.ic_back);
        backButton.setColorFilter(Color.WHITE);
        backButton.setBackgroundColor(Color.TRANSPARENT);
        backButton.setContentDescription("Назад");
        backButton.setVisibility(View.INVISIBLE);
        backButton.setOnClickListener(v -> goBack());
        toolbar.addView(backButton, new LinearLayout.LayoutParams(dp(48), dp(48)));

        toolbarTitle = new TextView(this);
        toolbarTitle.setText("LIGRIK");
        toolbarTitle.setTextColor(Color.WHITE);
        toolbarTitle.setTextSize(20);
        toolbarTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        toolbarTitle.setGravity(Gravity.CENTER);
        toolbarTitle.setLetterSpacing(0.08f);
        toolbar.addView(toolbarTitle, new LinearLayout.LayoutParams(0, dp(56), 1f));

        refreshButton = new ImageButton(this);
        refreshButton.setImageResource(R.drawable.ic_refresh);
        refreshButton.setColorFilter(Color.WHITE);
        refreshButton.setBackgroundColor(Color.TRANSPARENT);
        refreshButton.setContentDescription("Обновить");
        refreshButton.setOnClickListener(v -> webView.reload());
        toolbar.addView(refreshButton, new LinearLayout.LayoutParams(dp(48), dp(48)));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);
        root.addView(progressBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(2)
        ));

        contentFrame = new FrameLayout(this);
        webView = new WebView(this);
        contentFrame.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        homeView = buildNativeHome();
        contentFrame.addView(homeView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        buildErrorView();
        root.addView(contentFrame, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ));

        LinearLayout bottomNav = new LinearLayout(this);
        bottomNav.setOrientation(LinearLayout.HORIZONTAL);
        bottomNav.setGravity(Gravity.CENTER);
        bottomNav.setPadding(dp(4), dp(3), dp(4), dp(3));
        bottomNav.setBackgroundColor(Color.rgb(250, 248, 243));
        root.addView(bottomNav, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(70)
        ));

        addNav(bottomNav, "Главная", R.drawable.ic_home, HOME_URL);
        addNav(bottomNav, "Каталог", R.drawable.ic_catalog, CATALOG_URL);
        addNav(bottomNav, "Корзина", R.drawable.ic_cart, CART_URL);
        addNav(bottomNav, "Профиль", R.drawable.ic_account, ACCOUNT_URL);

        // Same idea for the gesture/navigation area at the bottom.
        View navigationBarSpacer = new View(this);
        navigationBarSpacer.setBackgroundColor(Color.rgb(250, 248, 243));
        root.addView(navigationBarSpacer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0
        ));

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            int left = insets.getSystemWindowInsetLeft();
            int right = insets.getSystemWindowInsetRight();

            LinearLayout.LayoutParams topLp = (LinearLayout.LayoutParams) statusBarSpacer.getLayoutParams();
            if (topLp.height != top) {
                topLp.height = top;
                statusBarSpacer.setLayoutParams(topLp);
            }

            LinearLayout.LayoutParams bottomLp = (LinearLayout.LayoutParams) navigationBarSpacer.getLayoutParams();
            if (bottomLp.height != bottom) {
                bottomLp.height = bottom;
                navigationBarSpacer.setLayoutParams(bottomLp);
            }

            toolbar.setPadding(dp(6) + left, 0, dp(6) + right, 0);
            bottomNav.setPadding(dp(4) + left, dp(3), dp(4) + right, dp(3));
            return insets;
        });

        setContentView(root);
        root.requestApplyInsets();
    }

    private ScrollView buildNativeHome() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(CREAM);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(body, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setImageResource(R.drawable.ic_ligrik);
        logo.setContentDescription("LIGRIK");
        body.addView(logo, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(74)
        ));
        RemoteImageLoader.load(this, logo, LOGO_URL);

        TextView eyebrow = text("● ИГРУШКИ ДЛЯ СЧАСТЛИВОГО ДЕТСТВА", 11, GREEN, true);
        eyebrow.setGravity(Gravity.CENTER);
        eyebrow.setLetterSpacing(0.06f);
        LinearLayout.LayoutParams eyebrowParams = wrap();
        eyebrowParams.gravity = Gravity.CENTER_HORIZONTAL;
        eyebrowParams.topMargin = dp(8);
        body.addView(eyebrow, eyebrowParams);

        TextView headline = text("Растём через игру", 30, DEEP_GREEN, true);
        headline.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams headlineParams = matchWrap();
        headlineParams.topMargin = dp(8);
        body.addView(headline, headlineParams);

        TextView subtitle = text("Развивающие деревянные игрушки, созданные с заботой о каждом этапе детства.", 15, MUTED, false);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams subtitleParams = matchWrap();
        subtitleParams.topMargin = dp(8);
        body.addView(subtitle, subtitleParams);

        LinearLayout gift = new LinearLayout(this);
        gift.setOrientation(LinearLayout.HORIZONTAL);
        gift.setGravity(Gravity.CENTER_VERTICAL);
        gift.setPadding(dp(14), dp(12), dp(14), dp(12));
        gift.setBackground(rounded(SOFT_GREEN, 20));
        LinearLayout.LayoutParams giftParams = matchWrap();
        giftParams.topMargin = dp(18);
        body.addView(gift, giftParams);

        TextView giftIcon = text("🎁", 28, GREEN, false);
        gift.addView(giftIcon, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout giftText = new LinearLayout(this);
        giftText.setOrientation(LinearLayout.VERTICAL);
        gift.addView(giftText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        giftText.addView(text("Именная крыша — в подарок", 16, DEEP_GREEN, true));
        TextView giftSub = text("Укажите имя ребёнка при заказе — изготовим бесплатно", 12, MUTED, false);
        LinearLayout.LayoutParams giftSubParams = matchWrap();
        giftSubParams.topMargin = dp(2);
        giftText.addView(giftSub, giftSubParams);

        TextView catalogBtn = pillButton("Смотреть весь каталог", GREEN, Color.WHITE);
        catalogBtn.setOnClickListener(v -> loadInternal(CATALOG_URL));
        LinearLayout.LayoutParams catalogBtnParams = matchWrap();
        catalogBtnParams.topMargin = dp(16);
        body.addView(catalogBtn, catalogBtnParams);

        TextView section = text("Выберите размер", 23, DEEP_GREEN, true);
        LinearLayout.LayoutParams sectionParams = matchWrap();
        sectionParams.topMargin = dp(26);
        body.addView(section, sectionParams);

        TextView sectionSub = text("Категории бизидомиков LIGRIK", 13, MUTED, false);
        LinearLayout.LayoutParams sectionSubParams = matchWrap();
        sectionSubParams.topMargin = dp(3);
        sectionSubParams.bottomMargin = dp(12);
        body.addView(sectionSub, sectionSubParams);

        body.addView(categoryCard("Маленькие бизидомики", "Компактные модели", IMG_SMALL, CAT_SMALL));
        body.addView(spacer(10));
        body.addView(categoryCard("Средние бизидомики", "Больше игровых элементов", IMG_MEDIUM, CAT_MEDIUM));
        body.addView(spacer(10));
        body.addView(categoryCard("Большие бизидомики", "Для долгой развивающей игры", IMG_LARGE, CAT_LARGE));
        body.addView(spacer(10));
        body.addView(categoryCard("Огромные бизидомики", "Максимум игровых возможностей", IMG_HUGE, CAT_HUGE));

        LinearLayout benefits = new LinearLayout(this);
        benefits.setOrientation(LinearLayout.VERTICAL);
        benefits.setPadding(dp(16), dp(16), dp(16), dp(16));
        benefits.setBackground(rounded(Color.WHITE, 20));
        LinearLayout.LayoutParams benefitsParams = matchWrap();
        benefitsParams.topMargin = dp(20);
        body.addView(benefits, benefitsParams);
        benefits.addView(text("Почему выбирают Лигрик", 18, DEEP_GREEN, true));
        benefits.addView(benefitLine("🌿", "Натуральное дерево"));
        benefits.addView(benefitLine("🛡", "Безопасные материалы"));
        benefits.addView(benefitLine("🧠", "Развитие мышления и моторики"));
        benefits.addView(benefitLine("🚚", "Бесплатная доставка от 3 000 ₽"));

        ImageView mascot = new ImageView(this);
        mascot.setScaleType(ImageView.ScaleType.FIT_CENTER);
        mascot.setContentDescription("Лигрик");
        LinearLayout.LayoutParams mascotParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(190)
        );
        mascotParams.topMargin = dp(14);
        body.addView(mascot, mascotParams);
        RemoteImageLoader.load(this, mascot, MASCOT_URL);

        TextView mascotText = text("Лигрик — друг, который растёт вместе с ребёнком", 17, DEEP_GREEN, true);
        mascotText.setGravity(Gravity.CENTER);
        body.addView(mascotText, matchWrap());

        return scroll;
    }

    private View categoryCard(String title, String subtitle, String imageUrl, String url) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(10), dp(10), dp(12), dp(10));
        card.setBackground(rounded(Color.WHITE, 20));
        card.setOnClickListener(v -> loadInternal(url));

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setContentDescription(title);
        image.setImageResource(R.drawable.ic_ligrik);
        card.addView(image, new LinearLayout.LayoutParams(dp(116), dp(112)));
        RemoteImageLoader.load(this, image, imageUrl);

        LinearLayout textWrap = new LinearLayout(this);
        textWrap.setOrientation(LinearLayout.VERTICAL);
        textWrap.setPadding(dp(12), 0, 0, 0);
        card.addView(textWrap, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        textWrap.addView(text(title, 17, DEEP_GREEN, true));
        TextView sub = text(subtitle, 12, MUTED, false);
        LinearLayout.LayoutParams subP = matchWrap();
        subP.topMargin = dp(3);
        textWrap.addView(sub, subP);
        TextView open = text("Смотреть →", 13, GREEN, true);
        LinearLayout.LayoutParams openP = matchWrap();
        openP.topMargin = dp(10);
        textWrap.addView(open, openP);
        return card;
    }

    private View benefitLine(String icon, String label) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowP = matchWrap();
        rowP.topMargin = dp(10);
        row.setLayoutParams(rowP);
        TextView i = text(icon, 20, GREEN, false);
        row.addView(i, new LinearLayout.LayoutParams(dp(34), dp(34)));
        row.addView(text(label, 14, MUTED, false), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return row;
    }

    private View spacer(int height) {
        Space space = new Space(this);
        space.setLayoutParams(new LinearLayout.LayoutParams(1, dp(height)));
        return space;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return t;
    }

    private TextView pillButton(String value, int bgColor, int textColor) {
        TextView t = text(value, 15, textColor, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(18), dp(14), dp(18), dp(14));
        t.setBackground(rounded(bgColor, 24));
        return t;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void buildErrorView() {
        errorView = new LinearLayout(this);
        errorView.setOrientation(LinearLayout.VERTICAL);
        errorView.setGravity(Gravity.CENTER);
        errorView.setPadding(dp(28), dp(28), dp(28), dp(28));
        errorView.setBackgroundColor(CREAM);
        errorView.setVisibility(View.GONE);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_offline);
        icon.setColorFilter(GREEN);
        errorView.addView(icon, new LinearLayout.LayoutParams(dp(58), dp(58)));

        TextView title = text("Нет соединения", 22, DEEP_GREEN, true);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleParams = wrap();
        titleParams.topMargin = dp(16);
        errorView.addView(title, titleParams);

        TextView message = text("Проверьте интернет и попробуйте ещё раз.\nКорзина останется в приложении.", 14, MUTED, false);
        message.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams messageParams = wrap();
        messageParams.topMargin = dp(8);
        errorView.addView(message, messageParams);

        TextView retry = pillButton("Повторить", GREEN, Color.WHITE);
        retry.setOnClickListener(v -> {
            errorView.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            webView.reload();
        });
        LinearLayout.LayoutParams retryParams = wrap();
        retryParams.topMargin = dp(20);
        errorView.addView(retry, retryParams);

        contentFrame.addView(errorView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
    }

    private void addNav(LinearLayout nav, String label, int iconRes, String url) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(3), dp(5), dp(3), dp(3));

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        item.addView(icon, new LinearLayout.LayoutParams(dp(24), dp(24)));

        TextView text = new TextView(this);
        text.setText(label);
        text.setTextSize(11);
        text.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams textParams = wrap();
        textParams.topMargin = dp(3);
        item.addView(text, textParams);

        NavItem navItem = new NavItem(item, icon, text, url);
        navItems.add(navItem);
        item.setOnClickListener(v -> {
            if (HOME_URL.equals(url)) showNativeHome();
            else loadInternal(url);
        });
        nav.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        s.setUserAgentString(s.getUserAgentString() + " LigrikAndroidApp/3.0");

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectAppCss();
                if (!showingHome) updateChrome(url, view.getTitle());
                errorView.setVisibility(View.GONE);
                CookieManager.getInstance().flush();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame() && !showingHome) {
                    webView.setVisibility(View.GONE);
                    errorView.setVisibility(View.VISIBLE);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                if (!showingHome) progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onShowFileChooser(WebView webView,
                                             ValueCallback<Uri[]> filePathCallbackNew,
                                             FileChooserParams fileChooserParams) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePathCallbackNew;

                Intent intent;
                try {
                    intent = fileChooserParams.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                }

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this,
                            "Не найдено приложение для выбора файла", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) ->
                openExternal(Uri.parse(url)));
    }

    private void injectAppCss() {
        String js = "(function(){" +
                "if(document.getElementById('ligrik-app-style'))return;" +
                "var s=document.createElement('style');s.id='ligrik-app-style';" +
                "s.innerHTML='header,footer{display:none!important;}" +
                ".fusion-header-wrapper,.fusion-footer{display:none!important;}" +
                "html,body{max-width:100%!important;overflow-x:hidden!important;}" +
                "input,select,textarea{font-size:16px!important;}" +
                "#wpadminbar{display:none!important;}" +
                "body{padding-top:0!important;margin-top:0!important;}';" +
                "document.head.appendChild(s);" +
                "})();";
        webView.evaluateJavascript(js, null);
    }

    private void showNativeHome() {
        showingHome = true;
        toolbar.setVisibility(View.GONE);
        progressBar.setVisibility(View.GONE);
        errorView.setVisibility(View.GONE);
        webView.setVisibility(View.GONE);
        homeView.setVisibility(View.VISIBLE);
        homeView.smoothScrollTo(0, 0);
        updateNav(HOME_URL);
    }

    private void loadInternal(String url) {
        showingHome = false;
        toolbar.setVisibility(View.VISIBLE);
        homeView.setVisibility(View.GONE);
        errorView.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
        if (url.equals(webView.getUrl())) {
            webView.reload();
        } else {
            webView.loadUrl(url);
        }
        updateChrome(url, null);
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();

        if (scheme.equals("https") || scheme.equals("http")) {
            if (host.equals("ligrik.ru") || host.equals("www.ligrik.ru") || host.endsWith(".ligrik.ru")) {
                showingHome = false;
                toolbar.setVisibility(View.VISIBLE);
                homeView.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
                return false;
            }
            openExternal(uri);
            return true;
        }

        if (scheme.equals("tel") || scheme.equals("mailto") || scheme.equals("sms") ||
                scheme.equals("geo") || scheme.equals("whatsapp") || scheme.equals("tg")) {
            openExternal(uri);
            return true;
        }

        if (scheme.equals("intent")) {
            try {
                Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return false;
    }

    private void updateChrome(String url, String pageTitle) {
        String safe = url == null ? "" : url;
        String title = "LIGRIK";
        if (safe.contains("/catalog")) title = "Каталог";
        else if (safe.contains("/product-category/")) title = "Каталог";
        else if (safe.contains("/cart")) title = "Корзина";
        else if (safe.contains("/checkout")) title = "Оформление заказа";
        else if (safe.contains("/my-account")) title = "Профиль";
        else if (safe.contains("/product/")) title = "Товар";
        else if (pageTitle != null && !pageTitle.trim().isEmpty()) {
            title = pageTitle.replace(" - Бизидомики и бизиборды из дерева - Лигрик - Развивающие игрушки", "");
            if (title.length() > 28) title = title.substring(0, 28) + "…";
        }
        toolbarTitle.setText(title);
        backButton.setVisibility(View.VISIBLE);
        refreshButton.setVisibility(View.VISIBLE);
        updateNav(safe);
    }

    private void updateNav(String current) {
        for (NavItem item : navItems) {
            boolean selected = isSectionSelected(current, item.url);
            int color = selected ? GREEN : Color.rgb(126, 141, 133);
            item.icon.setColorFilter(color);
            item.text.setTextColor(color);
            item.text.setTypeface(Typeface.DEFAULT, selected ? Typeface.BOLD : Typeface.NORMAL);
            if (selected) {
                item.container.setBackground(rounded(SOFT_GREEN, 18));
            } else {
                item.container.setBackgroundColor(Color.TRANSPARENT);
            }
        }
    }

    private boolean isSectionSelected(String current, String navUrl) {
        if (HOME_URL.equals(navUrl)) return HOME_URL.equals(current);
        if (current == null) return false;
        if (CAT_SMALL.equals(current) || CAT_MEDIUM.equals(current) || CAT_LARGE.equals(current) || CAT_HUGE.equals(current)) {
            return CATALOG_URL.equals(navUrl);
        }
        try {
            String navPath = Uri.parse(navUrl).getPath();
            String currentPath = Uri.parse(current).getPath();
            if (CATALOG_URL.equals(navUrl) && currentPath != null && currentPath.startsWith("/product-category/")) return true;
            return navPath != null && currentPath != null && currentPath.startsWith(navPath);
        } catch (Exception e) {
            return false;
        }
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show();
        }
    }

    private void goBack() {
        if (showingHome) {
            finish();
            return;
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            showNativeHome();
        }
    }

    @Override
    public void onBackPressed() {
        goBack();
    }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;
        Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
        filePathCallback.onReceiveValue(result);
        filePathCallback = null;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static class NavItem {
        final LinearLayout container;
        final ImageView icon;
        final TextView text;
        final String url;

        NavItem(LinearLayout container, ImageView icon, TextView text, String url) {
            this.container = container;
            this.icon = icon;
            this.text = text;
            this.url = url;
        }
    }
}
