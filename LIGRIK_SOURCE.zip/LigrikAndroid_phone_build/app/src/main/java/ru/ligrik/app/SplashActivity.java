package ru.ligrik.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Space;
import android.widget.TextView;

public class SplashActivity extends Activity {
    private static final String LOGO_URL = "https://ligrik.ru/wp-content/uploads/2026/07/ligrik-logo-kubiki.webp";
    private static final String MASCOT_URL = "https://ligrik.ru/wp-content/uploads/2026/07/ligrik-otdelno-ot-logo.webp";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(31, 77, 58));
        getWindow().setNavigationBarColor(Color.rgb(246, 240, 230));
        buildSplash();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, 1450);
    }

    private void buildSplash() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(246, 240, 230));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(dp(28), dp(42), dp(28), dp(24));
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        TextView eyebrow = new TextView(this);
        eyebrow.setText("●  ИГРУШКИ ДЛЯ СЧАСТЛИВОГО ДЕТСТВА");
        eyebrow.setTextSize(11);
        eyebrow.setTextColor(Color.rgb(31, 77, 58));
        eyebrow.setGravity(Gravity.CENTER);
        eyebrow.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        eyebrow.setLetterSpacing(0.08f);
        content.addView(eyebrow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setContentDescription("Логотип Лигрик");
        logo.setImageResource(R.drawable.ic_ligrik);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(310), dp(100));
        logoParams.topMargin = dp(24);
        content.addView(logo, logoParams);
        RemoteImageLoader.load(this, logo, LOGO_URL);

        TextView headline = new TextView(this);
        headline.setText("Растём через игру");
        headline.setTextSize(29);
        headline.setTextColor(Color.rgb(25, 51, 40));
        headline.setGravity(Gravity.CENTER);
        headline.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams headlineParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        headlineParams.topMargin = dp(10);
        content.addView(headline, headlineParams);

        TextView subtitle = new TextView(this);
        subtitle.setText("Натуральные деревянные игрушки\nдля развития мышления, моторики и воображения");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.rgb(74, 91, 83));
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        subtitleParams.topMargin = dp(10);
        content.addView(subtitle, subtitleParams);

        ImageView mascot = new ImageView(this);
        mascot.setScaleType(ImageView.ScaleType.FIT_CENTER);
        mascot.setContentDescription("Лигрик");
        LinearLayout.LayoutParams mascotParams = new LinearLayout.LayoutParams(dp(300), dp(166));
        mascotParams.topMargin = dp(16);
        content.addView(mascot, mascotParams);
        RemoteImageLoader.load(this, mascot, MASCOT_URL);

        TextView chip = new TextView(this);
        chip.setText("🌿 Натуральное дерево   ✓ Безопасные материалы");
        chip.setTextSize(12);
        chip.setTextColor(Color.rgb(31, 77, 58));
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(16), dp(10), dp(16), dp(10));
        GradientDrawable chipBg = new GradientDrawable();
        chipBg.setColor(Color.rgb(232, 239, 234));
        chipBg.setCornerRadius(dp(22));
        chip.setBackground(chipBg);
        LinearLayout.LayoutParams chipParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        chipParams.topMargin = dp(6);
        content.addView(chip, chipParams);

        Space space = new Space(this);
        content.addView(space, new LinearLayout.LayoutParams(1, 0, 1f));

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleSmall);
        progress.setIndeterminate(true);
        content.addView(progress, new LinearLayout.LayoutParams(dp(28), dp(28)));

        TextView loading = new TextView(this);
        loading.setText("Открываем магазин LIGRIK");
        loading.setTextSize(12);
        loading.setTextColor(Color.rgb(93, 107, 100));
        loading.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams loadingParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        loadingParams.topMargin = dp(8);
        content.addView(loading, loadingParams);

        setContentView(root);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
