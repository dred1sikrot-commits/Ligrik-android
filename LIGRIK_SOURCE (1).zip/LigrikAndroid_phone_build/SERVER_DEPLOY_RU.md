# Что нужно для запуска собственного сервера LIGRIK

Для полноценного LIGRIK Native 2.0 нужен сервер, доступный приложению по HTTPS.

Рекомендуемая схема:

- DNS: `api.ligrik.ru` -> IP сервера;
- сервер: Linux VPS с Docker;
- приложение: контейнер `backend`;
- HTTPS: Caddy из папки `deploy`;
- постоянные данные: Docker volumes для БД и фотографий.

## На сервере

1. Скопировать проект.
2. `cp backend/.env.example backend/.env`
3. Указать длинный случайный `ADMIN_TOKEN`.
4. Указать `PUBLIC_BASE_URL=https://api.ligrik.ru`.
5. Добавить `YOOKASSA_SHOP_ID` и `YOOKASSA_SECRET_KEY`.
6. Не задавать `YOOKASSA_VAT_CODE`, пока код НДС/фискализации не подтверждён для вашего магазина.
7. Из папки `deploy`: `docker compose up -d --build`.
8. Проверить `https://api.ligrik.ru/v1/health`.
9. Открыть `https://api.ligrik.ru/admin?token=...` и выполнить однократный импорт каталога.
10. В ЮKassa указать webhook: `https://api.ligrik.ru/v1/webhooks/yookassa`.

После этого можно собирать APK ветки Native 2.0.
