package ru.ligrik.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class RemoteImageLoader {
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(3);
    private static final int MAX_DECODE_SIDE = 1400;

    private RemoteImageLoader() {}

    public static void load(Activity activity, ImageView imageView, String url) {
        if (url == null || url.trim().isEmpty()) return;
        imageView.setTag(url);
        EXECUTOR.execute(() -> {
            Bitmap bitmap = null;
            try {
                File cacheDir = new File(activity.getCacheDir(), "brand_images");
                if (!cacheDir.exists()) cacheDir.mkdirs();
                File cached = new File(cacheDir, sha1(url) + ".img");
                byte[] bytes = null;

                if (cached.exists() && cached.length() > 0) {
                    try (InputStream in = new FileInputStream(cached)) {
                        bytes = readAll(in);
                    }
                }

                if (bytes == null || bytes.length == 0) {
                    HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(12000);
                    connection.setInstanceFollowRedirects(true);
                    connection.setRequestProperty("User-Agent", "LIGRIK-Native-Android/5.0");
                    connection.connect();
                    if (connection.getResponseCode() >= 200 && connection.getResponseCode() < 300) {
                        try (InputStream in = connection.getInputStream()) {
                            bytes = readAll(in);
                        }
                        if (bytes != null && bytes.length > 0) {
                            try (FileOutputStream out = new FileOutputStream(cached)) {
                                out.write(bytes);
                            }
                        }
                    }
                    connection.disconnect();
                }

                if (bytes != null && bytes.length > 0) bitmap = decodeSampled(bytes);
            } catch (Exception ignored) {
                // UI remains usable with the placeholder when a remote image fails.
            }

            Bitmap result = bitmap;
            if (result != null && !activity.isFinishing()) {
                activity.runOnUiThread(() -> {
                    Object tag = imageView.getTag();
                    if (url.equals(tag)) imageView.setImageBitmap(result);
                });
            }
        });
    }

    private static Bitmap decodeSampled(byte[] bytes) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
        int sample = 1;
        int max = Math.max(bounds.outWidth, bounds.outHeight);
        while (max / sample > MAX_DECODE_SIDE && sample < 16) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = Math.max(1, sample);
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
    }

    private static byte[] readAll(InputStream inputStream) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int count;
        while ((count = inputStream.read(buffer)) != -1) output.write(buffer, 0, count);
        return output.toByteArray();
    }

    private static String sha1(String value) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-1");
        byte[] bytes = digest.digest(value.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
